-- ============================================================
--  Sistema de préstamo de equipos de laboratorio
--  Ejecutar completo en: Supabase Dashboard > SQL Editor > New query
-- ============================================================

-- ------------------------------------------------------------
-- 1. Tipos
-- ------------------------------------------------------------
do $$
begin
  create type public.user_role as enum ('estudiante', 'administrador');
exception when duplicate_object then null;
end $$;

do $$
begin
  create type public.equipment_status as enum ('disponible', 'prestado', 'mantenimiento');
exception when duplicate_object then null;
end $$;

do $$
begin
  create type public.loan_status as enum ('pendiente', 'aprobado', 'rechazado', 'devuelto');
exception when duplicate_object then null;
end $$;

-- ------------------------------------------------------------
-- 2. Tablas
-- ------------------------------------------------------------

-- Perfil público vinculado 1:1 con auth.users
create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text not null,
  carnet      text not null,
  carrera     text not null,
  avatar_url  text,
  role        public.user_role not null default 'estudiante',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- El carnet no distingue mayúsculas/minúsculas ni espacios al inicio/fin
create unique index if not exists profiles_carnet_unique
  on public.profiles (lower(trim(carnet)));

-- Catálogo de equipos
create table if not exists public.equipment (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  description text not null,
  category    text,
  image_url   text,
  status      public.equipment_status not null default 'disponible',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists equipment_status_idx on public.equipment (status);

-- Solicitudes / préstamos
create table if not exists public.loans (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null,
  equipment_id  uuid not null,
  loan_date     date not null default current_date,
  due_date      date not null,
  return_date   timestamptz,
  status        public.loan_status not null default 'pendiente',
  notes         text,
  reviewed_by   uuid,
  reviewed_at   timestamptz,
  created_at    timestamptz not null default now(),

  constraint loans_user_id_fkey
    foreign key (user_id) references public.profiles (id) on delete cascade,
  constraint loans_equipment_id_fkey
    foreign key (equipment_id) references public.equipment (id) on delete restrict,
  constraint loans_reviewed_by_fkey
    foreign key (reviewed_by) references public.profiles (id) on delete set null,
  constraint loans_due_date_check
    check (due_date >= loan_date)
);

create index if not exists loans_user_id_idx on public.loans (user_id);
create index if not exists loans_equipment_id_idx on public.loans (equipment_id);
create index if not exists loans_status_idx on public.loans (status);

-- Un equipo físico solo puede tener un préstamo aprobado a la vez
create unique index if not exists loans_one_approved_per_equipment
  on public.loans (equipment_id)
  where status = 'aprobado';

-- Un estudiante no puede tener dos solicitudes activas del mismo equipo
create unique index if not exists loans_one_active_per_user_equipment
  on public.loans (user_id, equipment_id)
  where status in ('pendiente', 'aprobado');

-- ------------------------------------------------------------
-- 3. Funciones auxiliares
-- ------------------------------------------------------------

-- Evita recursión infinita en las políticas RLS de profiles
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role = 'administrador'
  );
$$;

grant execute on function public.is_admin() to authenticated;

-- Permite validar el carnet durante el registro sin exponer la tabla profiles
create or replace function public.carnet_disponible(p_carnet text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select not exists (
    select 1
    from public.profiles
    where lower(trim(carnet)) = lower(trim(p_carnet))
  );
$$;

grant execute on function public.carnet_disponible(text) to anon, authenticated;

-- Crea el perfil automáticamente al registrarse en Supabase Auth
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, carnet, carrera, avatar_url, role)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1), 'Sin nombre'),
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'carnet'), ''), new.id::text),
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'carrera'), ''), 'Sin asignar'),
    nullif(new.raw_user_meta_data ->> 'avatar_url', ''),
    'estudiante' -- el rol nunca se toma del cliente
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Un estudiante no puede cambiarse el rol ni el carnet
create or replace function public.handle_profile_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and not public.is_admin() then
    new.role := old.role;
    new.carnet := old.carnet;
  end if;

  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists on_profile_updated on public.profiles;
create trigger on_profile_updated
  before update on public.profiles
  for each row execute function public.handle_profile_update();

-- Mantiene updated_at en equipos
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists on_equipment_updated on public.equipment;
create trigger on_equipment_updated
  before update on public.equipment
  for each row execute function public.set_updated_at();

-- Sincroniza el estado del equipo cuando cambia el estado del préstamo
create or replace function public.handle_loan_status_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if old.status is distinct from new.status then
    if new.status = 'aprobado' then
      if old.status <> 'pendiente' then
        raise exception 'Solo se puede aprobar una solicitud pendiente';
      end if;

      update public.equipment
         set status = 'prestado', updated_at = now()
       where id = new.equipment_id
         and status = 'disponible';

      if not found then
        raise exception 'El equipo ya no está disponible';
      end if;

      new.reviewed_at := coalesce(new.reviewed_at, now());

    elsif new.status = 'devuelto' then
      if old.status <> 'aprobado' then
        raise exception 'Solo se puede devolver un préstamo aprobado';
      end if;

      new.return_date := coalesce(new.return_date, now());

      update public.equipment
         set status = 'disponible', updated_at = now()
       where id = new.equipment_id
         and status = 'prestado';

    elsif new.status = 'rechazado' then
      if old.status <> 'pendiente' then
        raise exception 'Solo se puede rechazar una solicitud pendiente';
      end if;

      new.reviewed_at := coalesce(new.reviewed_at, now());
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists on_loan_status_change on public.loans;
create trigger on_loan_status_change
  before update on public.loans
  for each row execute function public.handle_loan_status_change();

-- Al crear una solicitud, el estudiante no puede falsificar estados ni fechas
create or replace function public.prepare_new_loan()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and not public.is_admin() then
    new.status := 'pendiente';
    new.loan_date := current_date;
    new.return_date := null;
    new.reviewed_by := null;
    new.reviewed_at := null;
  end if;

  if new.due_date < current_date then
    raise exception 'La fecha de devolución no puede ser anterior a hoy';
  end if;

  if not exists (
    select 1
    from public.equipment
    where id = new.equipment_id
      and status = 'disponible'
  ) then
    raise exception 'El equipo no está disponible para préstamo';
  end if;

  return new;
end;
$$;

drop trigger if exists on_loan_created on public.loans;
create trigger on_loan_created
  before insert on public.loans
  for each row execute function public.prepare_new_loan();

-- ------------------------------------------------------------
-- 4. Row Level Security
-- ------------------------------------------------------------
alter table public.profiles  enable row level security;
alter table public.equipment enable row level security;
alter table public.loans     enable row level security;

-- PROFILES
drop policy if exists profiles_select_own_or_admin on public.profiles;
create policy profiles_select_own_or_admin
  on public.profiles for select
  to authenticated
  using (id = (select auth.uid()) or public.is_admin());

drop policy if exists profiles_update_own_or_admin on public.profiles;
create policy profiles_update_own_or_admin
  on public.profiles for update
  to authenticated
  using (id = (select auth.uid()) or public.is_admin())
  with check (id = (select auth.uid()) or public.is_admin());

-- EQUIPMENT: todos los usuarios autenticados leen; solo admin escribe
drop policy if exists equipment_select_authenticated on public.equipment;
create policy equipment_select_authenticated
  on public.equipment for select
  to authenticated
  using (true);

drop policy if exists equipment_insert_admin on public.equipment;
create policy equipment_insert_admin
  on public.equipment for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists equipment_update_admin on public.equipment;
create policy equipment_update_admin
  on public.equipment for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists equipment_delete_admin on public.equipment;
create policy equipment_delete_admin
  on public.equipment for delete
  to authenticated
  using (public.is_admin());

-- LOANS
drop policy if exists loans_select_own_or_admin on public.loans;
create policy loans_select_own_or_admin
  on public.loans for select
  to authenticated
  using (user_id = (select auth.uid()) or public.is_admin());

-- El estudiante solo puede crear solicitudes propias y siempre en estado pendiente
drop policy if exists loans_insert_own_pending on public.loans;
create policy loans_insert_own_pending
  on public.loans for insert
  to authenticated
  with check (
    user_id = (select auth.uid())
    and status = 'pendiente'
  );

-- Solo el administrador aprueba, rechaza o marca devuelto
drop policy if exists loans_update_admin on public.loans;
create policy loans_update_admin
  on public.loans for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- No se permite DELETE: el historial se conserva

-- ------------------------------------------------------------
-- 5. Reporte de equipos más solicitados
-- ------------------------------------------------------------
drop view if exists public.equipment_request_report;

create or replace view public.equipment_request_report
with (security_invoker = true)
as
select
  e.id            as equipment_id,
  e.name,
  e.category,
  e.image_url,
  count(l.id)                                               as total_requests,
  count(l.id) filter (where l.status = 'pendiente')         as pending_requests,
  count(l.id) filter (where l.status = 'aprobado')          as approved_requests,
  count(l.id) filter (where l.status = 'rechazado')         as rejected_requests,
  count(l.id) filter (where l.status = 'devuelto')          as returned_requests,
  max(l.created_at)                                         as last_requested_at
from public.equipment e
left join public.loans l on l.equipment_id = e.id
group by e.id, e.name, e.category, e.image_url
order by total_requests desc, e.name asc;

grant select on public.equipment_request_report to authenticated;

-- ------------------------------------------------------------
-- 6. Permisos
-- ------------------------------------------------------------
grant usage on schema public to anon, authenticated;

grant select, update
  on public.profiles to authenticated;

grant select, insert, update, delete
  on public.equipment to authenticated;

grant select, insert, update
  on public.loans to authenticated;

-- ------------------------------------------------------------
-- 7. Storage: fotos de perfil e imágenes de equipos
-- ------------------------------------------------------------
insert into storage.buckets (id, name, public)
values
  ('avatars', 'avatars', true),
  ('equipment', 'equipment', true)
on conflict (id) do nothing;

-- Lectura pública
drop policy if exists avatars_public_read on storage.objects;
create policy avatars_public_read
  on storage.objects for select
  using (bucket_id = 'avatars');

drop policy if exists equipment_images_public_read on storage.objects;
create policy equipment_images_public_read
  on storage.objects for select
  using (bucket_id = 'equipment');

-- El usuario sube su foto en avatars/<user_id>/...
drop policy if exists avatars_insert_own on storage.objects;
create policy avatars_insert_own
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'avatars'
    and (storage.foldername(name))[1] = (select auth.uid())::text
  );

drop policy if exists avatars_update_own on storage.objects;
create policy avatars_update_own
  on storage.objects for update
  to authenticated
  using (bucket_id = 'avatars' and owner = (select auth.uid()))
  with check (bucket_id = 'avatars' and owner = (select auth.uid()));

drop policy if exists avatars_delete_own on storage.objects;
create policy avatars_delete_own
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'avatars' and owner = (select auth.uid()));

-- Solo el administrador administra las imágenes del catálogo
drop policy if exists equipment_images_insert_admin on storage.objects;
create policy equipment_images_insert_admin
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'equipment' and public.is_admin());

drop policy if exists equipment_images_update_admin on storage.objects;
create policy equipment_images_update_admin
  on storage.objects for update
  to authenticated
  using (bucket_id = 'equipment' and public.is_admin())
  with check (bucket_id = 'equipment' and public.is_admin());

drop policy if exists equipment_images_delete_admin on storage.objects;
create policy equipment_images_delete_admin
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'equipment' and public.is_admin());

-- ------------------------------------------------------------
-- 8. Convertir un usuario en administrador
--    (ejecutar después de crear la cuenta desde Authentication > Users
--     o desde el registro normal de la app)
-- ------------------------------------------------------------
-- update public.profiles
--    set role = 'administrador'
--  where id = (select id from auth.users where email = 'admin@universidad.edu');
