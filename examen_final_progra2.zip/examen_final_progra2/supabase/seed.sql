-- Datos de ejemplo para el catálogo.
-- Ejecutar después de schema.sql. Solo inserta si el catálogo está vacío.

insert into public.equipment (name, description, category, image_url)
select v.name, v.description, v.category, v.image_url
from (values
  (
    'Microscopio binocular',
    'Microscopio óptico binocular con aumentos 40x, 100x, 400x y 1000x. Incluye estuche y cables.',
    'Biología',
    'https://images.unsplash.com/photo-1518152006812-edab29b069ac?auto=format&fit=crop&w=800&q=80'
  ),
  (
    'Laptop HP Pavilion',
    'Laptop para prácticas de programación. Procesador i5, 16 GB RAM, 512 GB SSD.',
    'Informática',
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80'
  ),
  (
    'Kit Arduino UNO',
    'Kit de desarrollo con placa Arduino UNO, protoboard, sensores, LEDs y resistencias.',
    'Electrónica',
    'https://images.unsplash.com/photo-1553406830-ef2513450d76?auto=format&fit=crop&w=800&q=80'
  ),
  (
    'Osciloscopio digital',
    'Osciloscopio digital de 2 canales, 100 MHz, con puntas de prueba y manual.',
    'Electrónica',
    'https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&w=800&q=80'
  ),
  (
    'Cámara réflex Canon',
    'Cámara fotográfica réflex con lente 18-55 mm, batería y tarjeta de memoria.',
    'Comunicación',
    'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80'
  ),
  (
    'Proyector Epson',
    'Proyector multimedia Full HD con cable HDMI y control remoto.',
    'Audiovisual',
    'https://images.unsplash.com/photo-1535016120720-40c646be5580?auto=format&fit=crop&w=800&q=80'
  )
) as v(name, description, category, image_url)
where not exists (select 1 from public.equipment);
