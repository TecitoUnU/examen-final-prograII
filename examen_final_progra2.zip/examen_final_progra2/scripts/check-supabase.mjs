/**
 * Comprueba que las credenciales de Supabase funcionan y que el esquema
 * mínimo está aplicado.
 *
 * Uso:
 *   npm run check:supabase
 *
 * Requiere Node.js 20.6 o superior (usa --env-file).
 */

const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.trim();
const key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY?.trim();

let failed = false;

function ok(message) {
  console.log(`  OK  ${message}`);
}

function warn(message) {
  console.log(`  !!  ${message}`);
}

function fail(message) {
  failed = true;
  console.error(`  XX  ${message}`);
}

if (!url || !key) {
  console.error('Faltan EXPO_PUBLIC_SUPABASE_URL o EXPO_PUBLIC_SUPABASE_ANON_KEY en .env');
  process.exit(1);
}

let host = url;
try {
  host = new URL(url).host;
} catch {
  console.error(`La URL no es válida: ${url}`);
  process.exit(1);
}

console.log('');
console.log('Verificando Supabase');
console.log(`  Proyecto: ${host}`);
console.log(`  Clave:    ${key.slice(0, 14)}... (${key.length} caracteres)`);
console.log('');

const headers = { apikey: key, Authorization: `Bearer ${key}` };

async function get(path) {
  const response = await fetch(`${url}${path}`, { headers });
  const text = await response.text();
  return { response, text };
}

// 1. La clave debe ser aceptada por el gateway de Auth.
try {
  const { response, text } = await get('/auth/v1/health');

  if (response.status === 200) {
    ok('La clave es válida para este proyecto.');
  } else if (response.status === 401) {
    fail(
      'La clave fue rechazada (401 Invalid API key). Copia de nuevo la publishable/anon key del proyecto.'
    );
  } else {
    fail(`Auth respondió ${response.status}: ${text.slice(0, 200)}`);
  }
} catch (error) {
  fail(`No se pudo conectar con ${host}: ${error?.message ?? error}`);
}

// 2. Las tablas deben existir. El acceso anónimo está restringido a propósito,
//    así que "permission denied" confirma que la tabla existe.
for (const table of ['equipment', 'profiles', 'loans']) {
  try {
    const { response, text } = await get(`/rest/v1/${table}?select=*&limit=1`);

    if (response.ok) {
      ok(`La tabla "${table}" responde correctamente.`);
    } else if (/permission denied|row-level security|42501|JWT/i.test(text)) {
      ok(`La tabla "${table}" existe (acceso anónimo restringido, es lo esperado).`);
    } else if (/does not exist|Could not find the table|PGRST205/i.test(text)) {
      fail(`Falta la tabla "${table}". Ejecuta supabase/schema.sql en el SQL Editor.`);
    } else {
      warn(`La tabla "${table}" respondió ${response.status}: ${text.slice(0, 160)}`);
    }
  } catch (error) {
    fail(`No se pudo consultar "${table}": ${error?.message ?? error}`);
  }
}

// 3. La función usada durante el registro también debe existir.
try {
  const response = await fetch(`${url}/rest/v1/rpc/carnet_disponible`, {
    method: 'POST',
    headers: { ...headers, 'Content-Type': 'application/json' },
    body: JSON.stringify({ p_carnet: '__verificacion__' }),
  });
  const text = await response.text();

  if (response.ok) {
    ok('La función "carnet_disponible" existe.');
  } else if (/does not exist|PGRST202/i.test(text)) {
    fail('Falta la función "carnet_disponible". Ejecuta supabase/schema.sql.');
  } else {
    warn(`La función "carnet_disponible" respondió ${response.status}: ${text.slice(0, 160)}`);
  }
} catch (error) {
  fail(`No se pudo probar "carnet_disponible": ${error?.message ?? error}`);
}

console.log('');

if (failed) {
  console.error('Hay problemas de configuración. Revisa GUIA_SUPABASE.md.');
  process.exit(1);
}

console.log('Todo listo. Ya puedes registrar usuarios y probar la app.');
