/**
 * Tipos compartidos de la aplicación.
 *
 * Reflejan las tablas y enums definidos en `supabase/schema.sql`.
 */

export type UserRole = 'estudiante' | 'administrador';

export type EquipmentStatus = 'disponible' | 'prestado' | 'mantenimiento';

export type LoanStatus = 'pendiente' | 'aprobado' | 'rechazado' | 'devuelto';

export type Profile = {
  id: string;
  full_name: string;
  carnet: string;
  carrera: string;
  avatar_url: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
};

export type Equipment = {
  id: string;
  name: string;
  description: string;
  category: string | null;
  image_url: string | null;
  status: EquipmentStatus;
  created_at: string;
  updated_at: string;
};

export type Loan = {
  id: string;
  user_id: string;
  equipment_id: string;
  loan_date: string;
  due_date: string;
  return_date: string | null;
  status: LoanStatus;
  notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
};

/** Perfil resumido del estudiante usado en el panel de administración. */
export type StudentSummary = Pick<
  Profile,
  'id' | 'full_name' | 'carnet' | 'carrera' | 'avatar_url'
>;

export type LoanWithRelations = Loan & {
  equipment: Equipment | null;
  student?: StudentSummary | null;
  reviewer?: Pick<Profile, 'id' | 'full_name'> | null;
};

export type EquipmentReportRow = {
  equipment_id: string;
  name: string;
  category: string | null;
  image_url: string | null;
  total_requests: number;
  pending_requests: number;
  approved_requests: number;
  rejected_requests: number;
  returned_requests: number;
  last_requested_at: string | null;
};

export type SignUpInput = {
  email: string;
  password: string;
  fullName: string;
  carnet: string;
  carrera: string;
};

export type UpdateProfileInput = {
  fullName: string;
  carrera: string;
  avatarUri?: string | null;
};
