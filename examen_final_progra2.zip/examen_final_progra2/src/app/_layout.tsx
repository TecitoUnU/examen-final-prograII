import { DarkTheme, DefaultTheme, Stack, ThemeProvider } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';

import { LoadingView } from '@/components/ui/loading-view';
import { AuthProvider, useAuth } from '@/context/auth-context';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { useTheme } from '@/hooks/use-theme';

SplashScreen.preventAutoHideAsync().catch(() => {
  // La pantalla de inicio ya pudo ocultarse.
});

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const dark = colorScheme === 'dark';

  return (
    <ThemeProvider value={dark ? DarkTheme : DefaultTheme}>
      <AuthProvider>
        <RootNavigator />
      </AuthProvider>
      <StatusBar style={dark ? 'light' : 'dark'} />
    </ThemeProvider>
  );
}

function RootNavigator() {
  const { initializing, session, profile, profileError } = useAuth();
  const theme = useTheme();

  const ready = !initializing && (!session || Boolean(profile) || Boolean(profileError));

  useEffect(() => {
    if (ready) {
      SplashScreen.hideAsync().catch(() => {
        // Ya estaba oculta.
      });
    }
  }, [ready]);

  if (!ready) {
    return <LoadingView label="Preparando tu cuenta..." />;
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: theme.background },
      }}>
      <Stack.Screen name="(app)" />
      <Stack.Screen name="(auth)" />
    </Stack>
  );
}
