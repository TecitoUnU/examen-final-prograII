import { Ionicons } from '@expo/vector-icons';
import { Link, router } from 'expo-router';
import { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button } from '@/components/ui/button';
import { ConfigWarning } from '@/components/ui/config-warning';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { InlineMessage } from '@/components/ui/inline-message';
import { PhotoPicker } from '@/components/ui/photo-picker';
import { TextField } from '@/components/ui/text-field';
import { Radii, Spacing } from '@/constants/theme';
import { useAuth } from '@/context/auth-context';
import { getErrorMessage } from '@/lib/errors';
import { isSupabaseConfigured } from '@/lib/supabase';
import { useTheme } from '@/hooks/use-theme';

export default function RegisterScreen() {
  const theme = useTheme();
  const { signUp } = useAuth();

  const [fullName, setFullName] = useState('');
  const [carnet, setCarnet] = useState('');
  const [carrera, setCarrera] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [emailConfirmationSent, setEmailConfirmationSent] = useState(false);

  const validate = () => {
    if (fullName.trim().length < 3) {
      return 'Ingresa tu nombre completo.';
    }
    if (carnet.trim().length < 4) {
      return 'Ingresa un carnet válido.';
    }
    if (carrera.trim().length < 3) {
      return 'Ingresa tu carrera.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return 'Ingresa un correo electrónico válido.';
    }
    if (password.length < 6) {
      return 'La contraseña debe tener al menos 6 caracteres.';
    }
    if (password !== confirmPassword) {
      return 'Las contraseñas no coinciden.';
    }
    return null;
  };

  const handleSubmit = async () => {
    setError(null);

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setBusy(true);

    try {
      const result = await signUp({
        fullName: fullName.trim(),
        carnet: carnet.trim(),
        carrera: carrera.trim(),
        email: email.trim(),
        password,
        avatarUri,
      });

      if (result.needsEmailConfirmation) {
        setEmailConfirmationSent(true);
      }
    } catch (caught) {
      setError(getErrorMessage(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.background }]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Link href="/login" asChild>
              <Pressable
                hitSlop={10}
                accessibilityLabel="Volver a iniciar sesión"
                style={({ pressed }) => [
                  styles.backButton,
                  { backgroundColor: theme.backgroundElement, borderColor: theme.border },
                  pressed && styles.pressed,
                ]}>
                <Ionicons name="arrow-back" size={20} color={theme.text} />
              </Pressable>
            </Link>

            <View style={styles.headerText}>
              <Text style={[styles.title, { color: theme.text }]}>Crear cuenta</Text>
              <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
                Regístrate como estudiante para solicitar equipos.
              </Text>
            </View>
          </View>

          {!isSupabaseConfigured ? <ConfigWarning /> : null}

          <View
            style={[
              styles.card,
              { backgroundColor: theme.backgroundElement, borderColor: theme.border },
            ]}>
            <PhotoPicker uri={avatarUri} name={fullName} onChange={setAvatarUri} disabled={busy} />

            <View style={[styles.divider, { backgroundColor: theme.border }]} />

            <TextField
              label="Nombre completo"
              placeholder="Ej. Ana María López"
              value={fullName}
              onChangeText={setFullName}
              icon="person-outline"
              autoCapitalize="words"
              autoComplete="name"
              textContentType="name"
              editable={!busy}
            />

            <TextField
              label="Carnet universitario"
              placeholder="Ej. 2019-12345"
              value={carnet}
              onChangeText={setCarnet}
              icon="id-card-outline"
              autoCapitalize="characters"
              autoCorrect={false}
              editable={!busy}
              hint="El carnet no se puede modificar después del registro."
            />

            <TextField
              label="Carrera"
              placeholder="Ej. Ingeniería en Sistemas"
              value={carrera}
              onChangeText={setCarrera}
              icon="school-outline"
              autoCapitalize="words"
              editable={!busy}
            />

            <TextField
              label="Correo electrónico"
              placeholder="tu.correo@universidad.edu"
              value={email}
              onChangeText={setEmail}
              icon="mail-outline"
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              autoComplete="email"
              textContentType="emailAddress"
              editable={!busy}
            />

            <TextField
              label="Contraseña"
              placeholder="Mínimo 6 caracteres"
              value={password}
              onChangeText={setPassword}
              icon="lock-closed-outline"
              secureTextEntry={!showPassword}
              rightIcon={showPassword ? 'eye-off-outline' : 'eye-outline'}
              onRightIconPress={() => setShowPassword((value) => !value)}
              autoCapitalize="none"
              autoComplete="new-password"
              textContentType="newPassword"
              editable={!busy}
              hint="Usa al menos 6 caracteres."
            />

            <TextField
              label="Confirmar contraseña"
              placeholder="Repite tu contraseña"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              icon="lock-closed-outline"
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              autoComplete="new-password"
              textContentType="newPassword"
              editable={!busy}
              returnKeyType="go"
              onSubmitEditing={handleSubmit}
            />

            {error ? <InlineMessage tone="danger" message={error} /> : null}

            <Button
              title="Crear cuenta"
              onPress={handleSubmit}
              icon="person-add-outline"
              loading={busy}
              disabled={!isSupabaseConfigured}
            />
          </View>

          <View style={styles.footer}>
            <Text style={[styles.footerText, { color: theme.textSecondary }]}>
              ¿Ya tienes cuenta?
            </Text>
            <Link href="/login" asChild>
              <Pressable hitSlop={8} style={({ pressed }) => pressed && styles.pressed}>
                <Text style={[styles.footerLink, { color: theme.primary }]}>Inicia sesión</Text>
              </Pressable>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ConfirmDialog
        visible={emailConfirmationSent}
        title="Cuenta creada"
        message="Te enviamos un correo de confirmación. Confírmalo y luego inicia sesión."
        confirmLabel="Ir a iniciar sesión"
        cancelLabel="Cerrar"
        onConfirm={() => {
          setEmailConfirmationSent(false);
          router.replace('/login');
        }}
        onCancel={() => setEmailConfirmationSent(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  scroll: {
    flexGrow: 1,
    padding: Spacing.four,
    gap: Spacing.three,
    maxWidth: 560,
    width: '100%',
    alignSelf: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.three,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: Radii.full,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    flex: 1,
    gap: 2,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.4,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
  },
  card: {
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.four,
    gap: Spacing.three,
  },
  divider: {
    height: StyleSheet.hairlineWidth,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.two,
    flexWrap: 'wrap',
  },
  footerText: {
    fontSize: 14,
  },
  footerLink: {
    fontSize: 14,
    fontWeight: '700',
  },
  pressed: {
    opacity: 0.6,
  },
});
