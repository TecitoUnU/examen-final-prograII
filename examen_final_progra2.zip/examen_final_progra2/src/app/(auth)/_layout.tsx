import { Redirect, Stack } from 'expo-router';

import { LoadingView } from '@/components/ui/loading-view';
import { useAuth } from '@/context/auth-context';
import { useTheme } from '@/hooks/use-theme';

export default function AuthLayout() {
  const { session, initializing } = useAuth();
  const theme = useTheme();

  if (initializing) {
    return <LoadingView label="Cargando..." />;
  }

  if (session) {
    return <Redirect href="/" />;
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: theme.background },
      }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
    </Stack>
  );
}
