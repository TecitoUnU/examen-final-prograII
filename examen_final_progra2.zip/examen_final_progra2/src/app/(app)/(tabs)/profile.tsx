import { Ionicons } from '@expo/vector-icons';
import { useCallback, useEffect, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Avatar } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { EmptyState } from '@/components/ui/empty-state';
import { InlineMessage } from '@/components/ui/inline-message';
import { PhotoPicker } from '@/components/ui/photo-picker';
import { TextField } from '@/components/ui/text-field';
import { Radii, Spacing } from '@/constants/theme';
import { USER_ROLE_LABEL } from '@/constants/status';
import { useAuth } from '@/context/auth-context';
import { getErrorMessage } from '@/lib/errors';
import { useTheme } from '@/hooks/use-theme';

export default function ProfileScreen() {
  const theme = useTheme();
  const {
    session,
    profile,
    profileError,
    profileLoading,
    isAdmin,
    updateProfile,
    refreshProfile,
    signOut,
  } = useAuth();

  const [fullName, setFullName] = useState('');
  const [carrera, setCarrera] = useState('');
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [removeAvatar, setRemoveAvatar] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [signOutOpen, setSignOutOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name);
      setCarrera(profile.carrera);
      setAvatarUri(null);
      setRemoveAvatar(false);
    }
  }, [profile]);

  const previewUri = removeAvatar ? null : (avatarUri ?? profile?.avatar_url ?? null);

  const handleAvatarChange = (uri: string | null) => {
    setSuccess(null);

    if (uri) {
      setAvatarUri(uri);
      setRemoveAvatar(false);
    } else {
      setAvatarUri(null);
      setRemoveAvatar(true);
    }
  };

  const handleSave = async () => {
    setError(null);
    setSuccess(null);

    if (!fullName.trim() || fullName.trim().length < 3) {
      setError('Ingresa tu nombre completo.');
      return;
    }

    if (!carrera.trim() || carrera.trim().length < 3) {
      setError('Ingresa tu carrera.');
      return;
    }

    setSaving(true);

    try {
      await updateProfile({
        fullName,
        carrera,
        avatarUri,
        removeAvatar,
      });

      setSuccess('Tu perfil se actualizó correctamente.');
    } catch (caught) {
      setError(getErrorMessage(caught));
    } finally {
      setSaving(false);
    }
  };

  const handleSignOut = useCallback(() => {
    setError(null);
    setSignOutOpen(true);
  }, []);

  const handleConfirmSignOut = useCallback(async () => {
    setSigningOut(true);

    try {
      await signOut();
      setSignOutOpen(false);
    } catch (caught) {
      setSignOutOpen(false);
      setError(getErrorMessage(caught));
    } finally {
      setSigningOut(false);
    }
  }, [signOut]);

  const signOutDialog = (
    <ConfirmDialog
      visible={signOutOpen}
      title="Cerrar sesión"
      message="¿Seguro que quieres salir de tu cuenta?"
      confirmLabel="Cerrar sesión"
      destructive
      loading={signingOut}
      onConfirm={handleConfirmSignOut}
      onCancel={() => setSignOutOpen(false)}
    />
  );

  if (!profile) {
    return (
      <SafeAreaView
        edges={['top', 'left', 'right']}
        style={[styles.safe, { backgroundColor: theme.background }]}>
        <View style={styles.fallbackHeader}>
          <Text style={[styles.title, { color: theme.text }]}>Mi perfil</Text>
        </View>
        <EmptyState
          icon="person-circle-outline"
          title="No pudimos cargar tu perfil"
          message={profileError ?? 'Vuelve a intentarlo en unos segundos.'}
          actionLabel="Reintentar"
          onAction={refreshProfile}
        />
        <View style={styles.fallbackFooter}>
          <Button
            title="Cerrar sesión"
            onPress={handleSignOut}
            variant="danger"
            icon="log-out-outline"
          />
        </View>
        {signOutDialog}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[styles.safe, { backgroundColor: theme.background }]}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={profileLoading}
              onRefresh={refreshProfile}
              tintColor={theme.primary}
              colors={[theme.primary]}
            />
          }>
          <View>
            <Text style={[styles.title, { color: theme.text }]}>Mi perfil</Text>
            <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
              Administra tus datos y tu foto de perfil.
            </Text>
          </View>

          <View
            style={[
              styles.identityCard,
              { backgroundColor: theme.backgroundElement, borderColor: theme.border },
            ]}>
            <Avatar uri={previewUri} name={profile.full_name} size={82} />
            <View style={styles.identityContent}>
              <Text style={[styles.name, { color: theme.text }]} numberOfLines={2}>
                {profile.full_name}
              </Text>
              <Text style={[styles.carnet, { color: theme.textSecondary }]}>
                Carnet {profile.carnet}
              </Text>
              <Badge
                label={USER_ROLE_LABEL[profile.role]}
                tone={isAdmin ? 'primary' : 'neutral'}
                icon={isAdmin ? 'shield-checkmark-outline' : 'school-outline'}
              />
            </View>
          </View>

          {isAdmin ? (
            <InlineMessage
              tone="primary"
              title="Cuenta de administrador"
              message="Puedes aprobar o rechazar solicitudes, registrar devoluciones y consultar el reporte de demanda."
            />
          ) : null}

          <View
            style={[
              styles.card,
              { backgroundColor: theme.backgroundElement, borderColor: theme.border },
            ]}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>Foto de perfil</Text>
            <PhotoPicker
              uri={previewUri}
              name={profile.full_name}
              onChange={handleAvatarChange}
              disabled={saving}
            />

            <View style={[styles.divider, { backgroundColor: theme.border }]} />

            <Text style={[styles.sectionTitle, { color: theme.text }]}>Datos personales</Text>

            <TextField
              label="Nombre completo"
              value={fullName}
              onChangeText={(value) => {
                setFullName(value);
                setSuccess(null);
              }}
              icon="person-outline"
              autoCapitalize="words"
              autoComplete="name"
              editable={!saving}
            />

            <TextField
              label="Carrera"
              value={carrera}
              onChangeText={(value) => {
                setCarrera(value);
                setSuccess(null);
              }}
              icon="school-outline"
              autoCapitalize="words"
              editable={!saving}
            />

            <TextField
              label="Carnet universitario"
              value={profile.carnet}
              icon="id-card-outline"
              editable={false}
              hint="El carnet no se puede modificar."
            />

            <TextField
              label="Correo electrónico"
              value={session?.user.email ?? ''}
              icon="mail-outline"
              editable={false}
              hint="El correo está asociado a tu cuenta de acceso."
            />

            {error ? <InlineMessage tone="danger" message={error} /> : null}
            {success ? <InlineMessage tone="success" message={success} /> : null}

            <Button
              title="Guardar cambios"
              onPress={handleSave}
              icon="save-outline"
              loading={saving}
            />
          </View>

          <View
            style={[
              styles.card,
              { backgroundColor: theme.backgroundElement, borderColor: theme.border },
            ]}>
            <View style={styles.accountHeader}>
              <Ionicons name="shield-checkmark-outline" size={18} color={theme.textSecondary} />
              <Text style={[styles.sectionTitle, { color: theme.text }]}>Cuenta</Text>
            </View>
            <Text style={[styles.accountText, { color: theme.textSecondary }]}>
              Tu sesión se mantiene activa en este dispositivo hasta que cierres sesión.
            </Text>
            <Button
              title="Cerrar sesión"
              onPress={handleSignOut}
              variant="danger"
              icon="log-out-outline"
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      {signOutDialog}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  flex: {
    flex: 1,
  },
  scroll: {
    padding: Spacing.three,
    paddingBottom: Spacing.six,
    gap: Spacing.three,
    maxWidth: 640,
    width: '100%',
    alignSelf: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
    marginTop: 2,
  },
  identityCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.three,
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.three,
  },
  identityContent: {
    flex: 1,
    gap: Spacing.one,
    alignItems: 'flex-start',
  },
  name: {
    fontSize: 18,
    fontWeight: '800',
    lineHeight: 23,
  },
  carnet: {
    fontSize: 12,
    fontWeight: '600',
  },
  card: {
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.three,
    gap: Spacing.three,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
  },
  divider: {
    height: StyleSheet.hairlineWidth,
  },
  accountHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
  },
  accountText: {
    fontSize: 12,
    lineHeight: 18,
  },
  fallbackHeader: {
    padding: Spacing.three,
  },
  fallbackFooter: {
    padding: Spacing.three,
  },
});
