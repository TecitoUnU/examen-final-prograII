import { Ionicons } from '@expo/vector-icons';
import { router, type Href } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import {
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { EquipmentCard } from '@/components/equipment-card';
import { EmptyState } from '@/components/ui/empty-state';
import { FilterChips, type FilterOption } from '@/components/ui/filter-chips';
import { InlineMessage } from '@/components/ui/inline-message';
import { LoadingView } from '@/components/ui/loading-view';
import { TextField } from '@/components/ui/text-field';
import { Avatar } from '@/components/ui/avatar';
import { Spacing } from '@/constants/theme';
import { EQUIPMENT_STATUS_OPTIONS } from '@/constants/status';
import { useAuth } from '@/context/auth-context';
import { getEquipment } from '@/lib/api';
import { firstName } from '@/lib/format';
import { useQuery } from '@/hooks/use-query';
import { useRefreshOnFocus } from '@/hooks/use-refresh-on-focus';
import { useTheme } from '@/hooks/use-theme';
import type { Equipment, EquipmentStatus } from '@/types';

type StatusFilter = EquipmentStatus | 'todos';

export default function CatalogScreen() {
  const theme = useTheme();
  const { profile, profileError, refreshProfile } = useAuth();

  const loader = useCallback(() => getEquipment(), []);
  const { data, loading, refreshing, error, refresh, reload } = useQuery(loader);
  useRefreshOnFocus(reload);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('todos');

  const equipment = useMemo(() => data ?? [], [data]);

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();

    return equipment.filter((item) => {
      const matchesStatus = statusFilter === 'todos' || item.status === statusFilter;
      if (!matchesStatus) return false;
      if (!query) return true;

      return (
        item.name.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        (item.category ?? '').toLowerCase().includes(query)
      );
    });
  }, [equipment, search, statusFilter]);

  const availableCount = equipment.filter((item) => item.status === 'disponible').length;

  const filterOptions: FilterOption<StatusFilter>[] = useMemo(
    () =>
      EQUIPMENT_STATUS_OPTIONS.map((option) => ({
        ...option,
        count:
          option.value === 'todos'
            ? equipment.length
            : equipment.filter((item) => item.status === option.value).length,
      })),
    [equipment]
  );

  const openEquipment = (item: Equipment) => {
    router.push(`/equipment/${item.id}` as Href);
  };

  const clearFilters = () => {
    setSearch('');
    setStatusFilter('todos');
  };

  const header = (
    <View style={styles.header}>
      <View style={styles.greetingRow}>
        <View style={styles.greeting}>
          <Text style={[styles.hello, { color: theme.textSecondary }]}>
            Hola, {firstName(profile?.full_name) || 'estudiante'}
          </Text>
          <Text style={[styles.title, { color: theme.text }]}>Catálogo de equipos</Text>
          <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
            Encuentra lo que necesitas para tu práctica.
          </Text>
        </View>

        <Pressable
          onPress={() => router.push('/profile' as Href)}
          accessibilityLabel="Ir a mi perfil"
          hitSlop={8}
          style={({ pressed }) => pressed && styles.pressed}>
          <Avatar uri={profile?.avatar_url} name={profile?.full_name} size={46} />
        </Pressable>
      </View>

      {profileError ? (
        <InlineMessage
          tone="danger"
          message={profileError}
          actionLabel="Reintentar"
          onAction={refreshProfile}
        />
      ) : null}

      <TextField
        placeholder="Buscar por nombre, categoría o descripción"
        value={search}
        onChangeText={setSearch}
        icon="search-outline"
        rightIcon={search ? 'close-circle' : undefined}
        onRightIconPress={() => setSearch('')}
        autoCapitalize="none"
        autoCorrect={false}
        returnKeyType="search"
        containerStyle={styles.search}
      />

      <FilterChips options={filterOptions} value={statusFilter} onChange={setStatusFilter} />

      <View style={styles.summaryRow}>
        <View style={[styles.availablePill, { backgroundColor: theme.successMuted }]}>
          <Ionicons name="checkmark-circle" size={14} color={theme.success} />
          <Text style={[styles.availableText, { color: theme.success }]}>
            {availableCount} {availableCount === 1 ? 'disponible' : 'disponibles'}
          </Text>
        </View>
        <Text style={[styles.resultText, { color: theme.textSecondary }]}>
          {filtered.length} {filtered.length === 1 ? 'resultado' : 'resultados'}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[styles.safe, { backgroundColor: theme.background }]}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <EquipmentCard equipment={item} onPress={() => openEquipment(item)} />
        )}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={styles.headerWrapper}
        ListEmptyComponent={
          loading ? (
            <LoadingView label="Cargando equipos..." fullScreen={false} />
          ) : error ? (
            <EmptyState
              icon="cloud-offline-outline"
              title="No pudimos cargar el catálogo"
              message={error}
              actionLabel="Reintentar"
              onAction={refresh}
            />
          ) : (
            <EmptyState
              icon="search-outline"
              title="Sin resultados"
              message="No encontramos equipos con los filtros seleccionados."
              actionLabel="Limpiar filtros"
              onAction={clearFilters}
            />
          )
        }
        contentContainerStyle={styles.listContent}
        keyboardShouldPersistTaps="handled"
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refresh}
            tintColor={theme.primary}
            colors={[theme.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  listContent: {
    padding: Spacing.three,
    paddingBottom: Spacing.six,
    gap: Spacing.three,
  },
  headerWrapper: {
    marginBottom: Spacing.two,
  },
  header: {
    gap: Spacing.three,
  },
  greetingRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.three,
  },
  greeting: {
    flex: 1,
    gap: 2,
  },
  hello: {
    fontSize: 13,
    fontWeight: '600',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
  },
  search: {
    gap: Spacing.one,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: Spacing.two,
  },
  availablePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.one,
    paddingHorizontal: Spacing.two,
    paddingVertical: 5,
    borderRadius: 999,
  },
  availableText: {
    fontSize: 12,
    fontWeight: '700',
  },
  resultText: {
    fontSize: 12,
    fontWeight: '600',
  },
  pressed: {
    opacity: 0.7,
  },
});
