import { router, type Href } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import {
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { LoanCard } from '@/components/loan-card';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { EmptyState } from '@/components/ui/empty-state';
import { FilterChips, type FilterOption } from '@/components/ui/filter-chips';
import { InlineMessage } from '@/components/ui/inline-message';
import { LoadingView } from '@/components/ui/loading-view';
import { StatCard } from '@/components/ui/stat-card';
import { Spacing } from '@/constants/theme';
import { LOAN_STATUS_OPTIONS } from '@/constants/status';
import { useAuth } from '@/context/auth-context';
import { getAllLoans, updateLoanStatus } from '@/lib/api';
import { getErrorMessage } from '@/lib/errors';
import { useQuery } from '@/hooks/use-query';
import { useRefreshOnFocus } from '@/hooks/use-refresh-on-focus';
import { useTheme } from '@/hooks/use-theme';
import type { LoanStatus, LoanWithRelations } from '@/types';

type StatusFilter = LoanStatus | 'todos';
type ActionStatus = 'aprobado' | 'rechazado' | 'devuelto';

const EMPTY_COPY: Record<StatusFilter, { title: string; message: string }> = {
  todos: {
    title: 'Todavía no hay solicitudes',
    message: 'Cuando los estudiantes soliciten equipos aparecerán aquí.',
  },
  pendiente: {
    title: 'No hay solicitudes pendientes',
    message: 'Todas las solicitudes ya fueron revisadas. Buen trabajo.',
  },
  aprobado: {
    title: 'No hay préstamos activos',
    message: 'Los préstamos aprobados que aún no se devuelven aparecerán aquí.',
  },
  devuelto: {
    title: 'No hay devoluciones registradas',
    message: 'Los préstamos marcados como devueltos aparecerán aquí.',
  },
  rechazado: {
    title: 'No hay solicitudes rechazadas',
    message: 'Las solicitudes rechazadas se conservan aquí como historial.',
  },
};

function getActionCopy(loan: LoanWithRelations, status: ActionStatus) {
  const equipmentName = loan.equipment?.name ?? 'el equipo';
  const studentName = loan.student?.full_name ?? 'el estudiante';

  const copy: Record<
    ActionStatus,
    { title: string; message: string; confirm: string; destructive: boolean }
  > = {
    aprobado: {
      title: 'Aprobar solicitud',
      message: `¿Aprobar el préstamo de "${equipmentName}" para ${studentName}? El equipo quedará marcado como prestado.`,
      confirm: 'Aprobar',
      destructive: false,
    },
    rechazado: {
      title: 'Rechazar solicitud',
      message: `¿Rechazar la solicitud de "${equipmentName}" de ${studentName}? Esta acción no se puede deshacer.`,
      confirm: 'Rechazar',
      destructive: true,
    },
    devuelto: {
      title: 'Registrar devolución',
      message: `¿Confirmar que ${studentName} devolvió "${equipmentName}"? El equipo volverá a estar disponible.`,
      confirm: 'Registrar devolución',
      destructive: false,
    },
  };

  return copy[status];
}

export default function AdminScreen() {
  const theme = useTheme();
  const { session, isAdmin } = useAuth();
  const userId = session?.user.id;

  const loader = useCallback(() => getAllLoans(), []);
  const { data, loading, refreshing, error, refresh, reload } = useQuery(loader);
  useRefreshOnFocus(reload);

  const [filter, setFilter] = useState<StatusFilter>('todos');
  const [busyLoan, setBusyLoan] = useState<{ id: string; action: LoanStatus } | null>(null);
  const [pendingAction, setPendingAction] = useState<{
    loan: LoanWithRelations;
    status: ActionStatus;
  } | null>(null);
  const [feedback, setFeedback] = useState<{
    tone: 'success' | 'danger';
    message: string;
  } | null>(null);

  const loans = useMemo(() => data ?? [], [data]);

  const counts = useMemo(
    () => ({
      pendiente: loans.filter((loan) => loan.status === 'pendiente').length,
      aprobado: loans.filter((loan) => loan.status === 'aprobado').length,
      devuelto: loans.filter((loan) => loan.status === 'devuelto').length,
    }),
    [loans]
  );

  const filterOptions: FilterOption<StatusFilter>[] = useMemo(
    () =>
      LOAN_STATUS_OPTIONS.map((option) => ({
        ...option,
        count:
          option.value === 'todos'
            ? loans.length
            : loans.filter((loan) => loan.status === option.value).length,
      })),
    [loans]
  );

  const filtered = useMemo(
    () => (filter === 'todos' ? loans : loans.filter((loan) => loan.status === filter)),
    [filter, loans]
  );

  const runAction = useCallback(
    async (loanId: string, status: ActionStatus) => {
      if (!userId) return;

      setBusyLoan({ id: loanId, action: status });

      try {
        await updateLoanStatus({ loanId, status, reviewerId: userId });
        await reload();

        const messages: Record<ActionStatus, string> = {
          aprobado: 'La solicitud fue aprobada y el equipo quedó marcado como prestado.',
          rechazado: 'La solicitud fue rechazada.',
          devuelto: 'La devolución se registró y el equipo volvió a estar disponible.',
        };

        setFeedback({ tone: 'success', message: messages[status] });
      } catch (caught) {
        setFeedback({
          tone: 'danger',
          message: `No se pudo actualizar la solicitud. ${getErrorMessage(caught)}`,
        });
      } finally {
        setBusyLoan(null);
      }
    },
    [reload, userId]
  );

  const confirmAction = useCallback((loan: LoanWithRelations, status: ActionStatus) => {
    setPendingAction({ loan, status });
  }, []);

  const pendingCopy = pendingAction
    ? getActionCopy(pendingAction.loan, pendingAction.status)
    : null;

  if (!isAdmin) {
    return (
      <SafeAreaView
        edges={['top', 'left', 'right']}
        style={[styles.safe, { backgroundColor: theme.background }]}>
        <View style={styles.headerOnly}>
          <Text style={[styles.title, { color: theme.text }]}>Solicitudes</Text>
        </View>
        <EmptyState
          icon="lock-closed-outline"
          title="Acceso restringido"
          message="Esta sección solo está disponible para administradores del laboratorio."
          actionLabel="Ir al catálogo"
          onAction={() => router.replace('/' as Href)}
        />
      </SafeAreaView>
    );
  }

  const emptyCopy = EMPTY_COPY[filter];

  const header = (
    <View style={styles.header}>
      <View>
        <Text style={[styles.title, { color: theme.text }]}>Solicitudes</Text>
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
          Aprueba, rechaza y registra devoluciones de equipos.
        </Text>
      </View>

      <View style={styles.statsRow}>
        <StatCard
          icon="time-outline"
          label="Pendientes"
          value={counts.pendiente}
          tone={theme.warning}
          background={theme.warningMuted}
        />
        <StatCard
          icon="swap-horizontal-outline"
          label="Activos"
          value={counts.aprobado}
          tone={theme.primary}
          background={theme.primaryMuted}
        />
        <StatCard
          icon="checkmark-done-outline"
          label="Devueltos"
          value={counts.devuelto}
          tone={theme.success}
          background={theme.successMuted}
        />
      </View>

      {feedback ? <InlineMessage tone={feedback.tone} message={feedback.message} /> : null}

      <FilterChips options={filterOptions} value={filter} onChange={setFilter} />
    </View>
  );

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[styles.safe, { backgroundColor: theme.background }]}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <LoanCard
            loan={item}
            showStudent
            onApprove={() => confirmAction(item, 'aprobado')}
            onReject={() => confirmAction(item, 'rechazado')}
            onReturn={() => confirmAction(item, 'devuelto')}
            busyAction={busyLoan?.id === item.id ? busyLoan.action : null}
          />
        )}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={styles.headerWrapper}
        ListEmptyComponent={
          loading ? (
            <LoadingView label="Cargando solicitudes..." fullScreen={false} />
          ) : error ? (
            <EmptyState
              icon="cloud-offline-outline"
              title="No pudimos cargar las solicitudes"
              message={error}
              actionLabel="Reintentar"
              onAction={refresh}
            />
          ) : (
            <EmptyState
              icon="clipboard-outline"
              title={emptyCopy.title}
              message={emptyCopy.message}
              actionLabel="Actualizar"
              onAction={reload}
            />
          )
        }
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refresh}
            tintColor={theme.primary}
            colors={[theme.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />

      <ConfirmDialog
        visible={pendingAction !== null}
        title={pendingCopy?.title ?? ''}
        message={pendingCopy?.message}
        confirmLabel={pendingCopy?.confirm ?? 'Confirmar'}
        destructive={pendingCopy?.destructive ?? false}
        loading={pendingAction ? busyLoan?.id === pendingAction.loan.id : false}
        onConfirm={() => {
          if (!pendingAction) return;
          const { loan, status } = pendingAction;
          setPendingAction(null);
          void runAction(loan.id, status);
        }}
        onCancel={() => setPendingAction(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  listContent: {
    padding: Spacing.three,
    paddingBottom: Spacing.six,
    gap: Spacing.three,
  },
  headerWrapper: {
    marginBottom: Spacing.two,
  },
  header: {
    gap: Spacing.three,
  },
  headerOnly: {
    padding: Spacing.three,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
    marginTop: 2,
  },
  statsRow: {
    flexDirection: 'row',
    gap: Spacing.two,
  },
});
