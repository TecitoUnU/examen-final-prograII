import { router, type Href } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { LoanCard } from '@/components/loan-card';
import { EmptyState } from '@/components/ui/empty-state';
import { FilterChips, type FilterOption } from '@/components/ui/filter-chips';
import { LoadingView } from '@/components/ui/loading-view';
import { StatCard } from '@/components/ui/stat-card';
import { Spacing } from '@/constants/theme';
import { LOAN_STATUS_OPTIONS } from '@/constants/status';
import { useAuth } from '@/context/auth-context';
import { getMyLoans } from '@/lib/api';
import { useQuery } from '@/hooks/use-query';
import { useRefreshOnFocus } from '@/hooks/use-refresh-on-focus';
import { useTheme } from '@/hooks/use-theme';
import type { LoanStatus } from '@/types';

type StatusFilter = LoanStatus | 'todos';

export default function MyLoansScreen() {
  const theme = useTheme();
  const { session } = useAuth();
  const userId = session?.user.id;

  const loader = useCallback(async () => {
    if (!userId) return [];
    return getMyLoans(userId);
  }, [userId]);

  const { data, loading, refreshing, error, refresh, reload } = useQuery(loader);
  useRefreshOnFocus(reload);

  const [filter, setFilter] = useState<StatusFilter>('todos');

  const loans = useMemo(() => data ?? [], [data]);

  const counts = useMemo(
    () => ({
      pendiente: loans.filter((loan) => loan.status === 'pendiente').length,
      aprobado: loans.filter((loan) => loan.status === 'aprobado').length,
      devuelto: loans.filter((loan) => loan.status === 'devuelto').length,
    }),
    [loans]
  );

  const filterOptions: FilterOption<StatusFilter>[] = useMemo(
    () =>
      LOAN_STATUS_OPTIONS.map((option) => ({
        ...option,
        count:
          option.value === 'todos'
            ? loans.length
            : loans.filter((loan) => loan.status === option.value).length,
      })),
    [loans]
  );

  const filtered = useMemo(
    () => (filter === 'todos' ? loans : loans.filter((loan) => loan.status === filter)),
    [filter, loans]
  );

  const header = (
    <View style={styles.header}>
      <View>
        <Text style={[styles.title, { color: theme.text }]}>Mis préstamos</Text>
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
          Sigue el estado de tus solicitudes y devoluciones.
        </Text>
      </View>

      <View style={styles.statsRow}>
        <StatCard
          icon="time-outline"
          label="Pendientes"
          value={counts.pendiente}
          tone={theme.warning}
          background={theme.warningMuted}
        />
        <StatCard
          icon="swap-horizontal-outline"
          label="Activos"
          value={counts.aprobado}
          tone={theme.primary}
          background={theme.primaryMuted}
        />
        <StatCard
          icon="checkmark-done-outline"
          label="Devueltos"
          value={counts.devuelto}
          tone={theme.success}
          background={theme.successMuted}
        />
      </View>

      <FilterChips options={filterOptions} value={filter} onChange={setFilter} />
    </View>
  );

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[styles.safe, { backgroundColor: theme.background }]}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <LoanCard loan={item} />}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={styles.headerWrapper}
        ListEmptyComponent={
          loading ? (
            <LoadingView label="Cargando préstamos..." fullScreen={false} />
          ) : error ? (
            <EmptyState
              icon="cloud-offline-outline"
              title="No pudimos cargar tus préstamos"
              message={error}
              actionLabel="Reintentar"
              onAction={refresh}
            />
          ) : loans.length === 0 ? (
            <EmptyState
              icon="file-tray-outline"
              title="Aún no tienes préstamos"
              message="Explora el catálogo y envía tu primera solicitud de equipo."
              actionLabel="Ver catálogo"
              onAction={() => router.push('/' as Href)}
            />
          ) : (
            <EmptyState
              icon="funnel-outline"
              title="Sin préstamos en este estado"
              message="No hay solicitudes que coincidan con el filtro seleccionado."
              actionLabel="Ver todos"
              onAction={() => setFilter('todos')}
            />
          )
        }
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refresh}
            tintColor={theme.primary}
            colors={[theme.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  listContent: {
    padding: Spacing.three,
    paddingBottom: Spacing.six,
    gap: Spacing.three,
  },
  headerWrapper: {
    marginBottom: Spacing.two,
  },
  header: {
    gap: Spacing.three,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
    marginTop: 2,
  },
  statsRow: {
    flexDirection: 'row',
    gap: Spacing.two,
  },
});
