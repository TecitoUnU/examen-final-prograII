import { Ionicons } from '@expo/vector-icons';
import { router, type Href } from 'expo-router';
import { useCallback, useMemo } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Badge } from '@/components/ui/badge';
import { EmptyState } from '@/components/ui/empty-state';
import { LoadingView } from '@/components/ui/loading-view';
import { Radii, Spacing } from '@/constants/theme';
import { useAuth } from '@/context/auth-context';
import { getEquipmentReport } from '@/lib/api';
import { formatDate, plural } from '@/lib/format';
import { useQuery } from '@/hooks/use-query';
import { useRefreshOnFocus } from '@/hooks/use-refresh-on-focus';
import { useTheme } from '@/hooks/use-theme';
import type { EquipmentReportRow } from '@/types';

export default function ReportScreen() {
  const theme = useTheme();
  const { isAdmin } = useAuth();

  const loader = useCallback(() => getEquipmentReport(), []);
  const { data, loading, refreshing, error, refresh, reload } = useQuery(loader);
  useRefreshOnFocus(reload);

  const rows = useMemo(() => data ?? [], [data]);

  const stats = useMemo(() => {
    const totalRequests = rows.reduce((sum, row) => sum + row.total_requests, 0);
    const maxRequests = Math.max(1, ...rows.map((row) => row.total_requests));
    return { totalRequests, maxRequests, top: rows[0] };
  }, [rows]);

  if (!isAdmin) {
    return (
      <SafeAreaView
        edges={['top', 'left', 'right']}
        style={[styles.safe, { backgroundColor: theme.background }]}>
        <View style={styles.headerOnly}>
          <Text style={[styles.title, { color: theme.text }]}>Reporte de demanda</Text>
        </View>
        <EmptyState
          icon="lock-closed-outline"
          title="Acceso restringido"
          message="El reporte de equipos más solicitados solo está disponible para administradores."
          actionLabel="Ir al catálogo"
          onAction={() => router.replace('/' as Href)}
        />
      </SafeAreaView>
    );
  }

  const header = (
    <View style={styles.header}>
      <View>
        <Text style={[styles.title, { color: theme.text }]}>Reporte de demanda</Text>
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
          Equipos más solicitados y desglose por estado.
        </Text>
      </View>

      <View style={styles.summaryRow}>
        <View
          style={[
            styles.summaryCard,
            { backgroundColor: theme.primaryMuted, borderColor: theme.primaryMuted },
          ]}>
          <View style={[styles.summaryIcon, { backgroundColor: theme.backgroundElement }]}>
            <Ionicons name="stats-chart" size={18} color={theme.primary} />
          </View>
          <Text style={[styles.summaryValue, { color: theme.primary }]}>{stats.totalRequests}</Text>
          <Text style={[styles.summaryLabel, { color: theme.textSecondary }]}>
            {plural(stats.totalRequests, 'solicitud total', 'solicitudes totales')}
          </Text>
        </View>

        <View
          style={[
            styles.summaryCard,
            { backgroundColor: theme.warningMuted, borderColor: theme.warningMuted },
          ]}>
          <View style={[styles.summaryIcon, { backgroundColor: theme.backgroundElement }]}>
            <Ionicons name="trophy" size={18} color={theme.warning} />
          </View>
          <Text
            style={[styles.summaryValue, styles.topName, { color: theme.warning }]}
            numberOfLines={2}>
            {stats.top?.name ?? '—'}
          </Text>
          <Text style={[styles.summaryLabel, { color: theme.textSecondary }]}>
            Más solicitado ({stats.top?.total_requests ?? 0})
          </Text>
        </View>
      </View>

      <View style={[styles.legend, { borderColor: theme.border }]}>
        <Ionicons name="information-circle-outline" size={15} color={theme.textSecondary} />
        <Text style={[styles.legendText, { color: theme.textSecondary }]}>
          Las barras comparan el total de solicitudes de cada equipo.
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView
      edges={['top', 'left', 'right']}
      style={[styles.safe, { backgroundColor: theme.background }]}>
      <FlatList
        data={rows}
        keyExtractor={(item) => item.equipment_id}
        renderItem={({ item, index }) => (
          <ReportRow row={item} rank={index + 1} maxRequests={stats.maxRequests} />
        )}
        ListHeaderComponent={header}
        ListHeaderComponentStyle={styles.headerWrapper}
        ListEmptyComponent={
          loading ? (
            <LoadingView label="Calculando el reporte..." fullScreen={false} />
          ) : error ? (
            <EmptyState
              icon="cloud-offline-outline"
              title="No pudimos cargar el reporte"
              message={error}
              actionLabel="Reintentar"
              onAction={refresh}
            />
          ) : (
            <EmptyState
              icon="bar-chart-outline"
              title="Sin datos todavía"
              message="Cuando existan equipos y solicitudes podrás ver aquí cuáles son los más pedidos."
              actionLabel="Actualizar"
              onAction={reload}
            />
          )
        }
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refresh}
            tintColor={theme.primary}
            colors={[theme.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

function ReportRow({
  row,
  rank,
  maxRequests,
}: {
  row: EquipmentReportRow;
  rank: number;
  maxRequests: number;
}) {
  const theme = useTheme();
  const percentage = Math.max(4, Math.round((row.total_requests / maxRequests) * 100));
  const top = rank === 1 && row.total_requests > 0;

  return (
    <View
      style={[
        styles.rowCard,
        {
          backgroundColor: theme.backgroundElement,
          borderColor: top ? theme.primary : theme.border,
        },
      ]}>
      <View style={styles.rowHeader}>
        <View
          style={[
            styles.rank,
            { backgroundColor: top ? theme.primary : theme.primaryMuted },
          ]}>
          <Text style={[styles.rankText, { color: top ? theme.onPrimary : theme.primary }]}>
            {rank}
          </Text>
        </View>

        <View style={styles.rowTitle}>
          <Text style={[styles.equipmentName, { color: theme.text }]} numberOfLines={2}>
            {row.name}
          </Text>
          <Text style={[styles.category, { color: theme.textSecondary }]} numberOfLines={1}>
            {row.category ?? 'Sin categoría'}
          </Text>
        </View>

        <View style={styles.totalBlock}>
          <Text style={[styles.total, { color: top ? theme.primary : theme.text }]}>
            {row.total_requests}
          </Text>
          <Text style={[styles.totalLabel, { color: theme.textSecondary }]}>
            {plural(row.total_requests, 'solicitud', 'solicitudes')}
          </Text>
        </View>
      </View>

      <View style={[styles.barTrack, { backgroundColor: theme.backgroundSelected }]}>
        <View
          style={[
            styles.barFill,
            { width: `${percentage}%`, backgroundColor: top ? theme.primary : theme.info },
          ]}
        />
      </View>

      <View style={styles.breakdown}>
        {row.pending_requests > 0 ? (
          <Badge label={`${row.pending_requests} pend.`} tone="warning" small />
        ) : null}
        {row.approved_requests > 0 ? (
          <Badge label={`${row.approved_requests} aprob.`} tone="primary" small />
        ) : null}
        {row.returned_requests > 0 ? (
          <Badge label={`${row.returned_requests} devuelt.`} tone="success" small />
        ) : null}
        {row.rejected_requests > 0 ? (
          <Badge label={`${row.rejected_requests} rechaz.`} tone="danger" small />
        ) : null}
        {row.total_requests === 0 ? (
          <Badge label="Sin solicitudes" tone="neutral" small />
        ) : null}
      </View>

      <Text style={[styles.lastRequested, { color: theme.textSecondary }]}>
        {row.last_requested_at
          ? `Última solicitud: ${formatDate(row.last_requested_at)}`
          : 'Aún no ha sido solicitado'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },
  listContent: {
    padding: Spacing.three,
    paddingBottom: Spacing.six,
    gap: Spacing.three,
  },
  headerWrapper: {
    marginBottom: Spacing.two,
  },
  header: {
    gap: Spacing.three,
  },
  headerOnly: {
    padding: Spacing.three,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    lineHeight: 18,
    marginTop: 2,
  },
  summaryRow: {
    flexDirection: 'row',
    gap: Spacing.two,
  },
  summaryCard: {
    flex: 1,
    borderWidth: 1,
    borderRadius: Radii.md,
    padding: Spacing.three,
    gap: 2,
  },
  summaryIcon: {
    width: 32,
    height: 32,
    borderRadius: Radii.full,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.one,
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: '800',
    lineHeight: 28,
  },
  topName: {
    fontSize: 15,
    lineHeight: 19,
    minHeight: 38,
  },
  summaryLabel: {
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  legend: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: Spacing.two,
  },
  legendText: {
    flex: 1,
    fontSize: 11,
    lineHeight: 16,
  },
  rowCard: {
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.three,
    gap: Spacing.two,
  },
  rowHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
  },
  rank: {
    width: 30,
    height: 30,
    borderRadius: Radii.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankText: {
    fontSize: 13,
    fontWeight: '800',
  },
  rowTitle: {
    flex: 1,
    gap: 1,
  },
  equipmentName: {
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 18,
  },
  category: {
    fontSize: 11,
  },
  totalBlock: {
    alignItems: 'flex-end',
  },
  total: {
    fontSize: 22,
    fontWeight: '800',
    lineHeight: 25,
  },
  totalLabel: {
    fontSize: 9,
    fontWeight: '700',
  },
  barTrack: {
    height: 8,
    borderRadius: Radii.full,
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: Radii.full,
  },
  breakdown: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.one,
  },
  lastRequested: {
    fontSize: 10,
    fontWeight: '600',
  },
});
