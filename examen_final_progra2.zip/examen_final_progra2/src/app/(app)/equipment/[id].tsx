import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, type Href } from 'expo-router';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { EquipmentImage } from '@/components/equipment-image';
import { EquipmentStatusBadge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { EmptyState } from '@/components/ui/empty-state';
import { InlineMessage } from '@/components/ui/inline-message';
import { LoadingView } from '@/components/ui/loading-view';
import { Screen } from '@/components/ui/screen';
import { TextField } from '@/components/ui/text-field';
import { Radii, Spacing } from '@/constants/theme';
import { useAuth } from '@/context/auth-context';
import { getActiveLoanForEquipment, getEquipmentById, requestLoan } from '@/lib/api';
import { getErrorMessage } from '@/lib/errors';
import { addDaysISO, formatDate, todayISO } from '@/lib/format';
import { useTheme } from '@/hooks/use-theme';
import type { Equipment, Loan } from '@/types';

const DURATIONS = [
  { days: 1, label: '1 día' },
  { days: 3, label: '3 días' },
  { days: 7, label: '1 semana' },
  { days: 14, label: '2 semanas' },
  { days: 21, label: '3 semanas' },
];

export default function EquipmentDetailScreen() {
  const theme = useTheme();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { session, profile, isAdmin } = useAuth();
  const userId = session?.user.id;

  const [equipment, setEquipment] = useState<Equipment | null>(null);
  const [activeLoan, setActiveLoan] = useState<Loan | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [days, setDays] = useState(7);
  const [notes, setNotes] = useState('');
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [requestSent, setRequestSent] = useState(false);

  const dueDate = useMemo(() => addDaysISO(days), [days]);

  const load = useCallback(async () => {
    if (!id) {
      setLoadError('No se recibió el identificador del equipo.');
      setLoading(false);
      return;
    }

    setLoading(true);
    setLoadError(null);

    try {
      const item = await getEquipmentById(id);
      setEquipment(item);

      if (userId) {
        const loan = await getActiveLoanForEquipment(userId, id);
        setActiveLoan(loan);
      } else {
        setActiveLoan(null);
      }
    } catch (caught) {
      setLoadError(getErrorMessage(caught));
    } finally {
      setLoading(false);
    }
  }, [id, userId]);

  useEffect(() => {
    load();
  }, [load]);

  const handleRequest = async () => {
    if (!equipment || !userId) return;

    setSubmitError(null);
    setSubmitting(true);

    try {
      await requestLoan({
        userId,
        equipmentId: equipment.id,
        dueDate,
        notes,
      });

      setRequestSent(true);
    } catch (caught) {
      setSubmitError(getErrorMessage(caught));
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <Screen edges={['top', 'left', 'right', 'bottom']} padded={false}>
        <LoadingView label="Cargando equipo..." />
      </Screen>
    );
  }

  if (loadError || !equipment) {
    return (
      <Screen edges={['top', 'left', 'right', 'bottom']}>
        <View style={styles.topBar}>
          <BackButton />
        </View>
        <EmptyState
          icon="cloud-offline-outline"
          title="No pudimos cargar el equipo"
          message={loadError ?? 'El equipo no existe o fue eliminado.'}
          actionLabel="Reintentar"
          onAction={load}
        />
      </Screen>
    );
  }

  const available = equipment.status === 'disponible';

  return (
    <Screen scroll edges={['top', 'left', 'right', 'bottom']} contentContainerStyle={styles.content}>
      <View style={styles.topBar}>
        <BackButton />
        <Text style={[styles.topTitle, { color: theme.text }]}>Detalle del equipo</Text>
        <View style={styles.topSpacer} />
      </View>

      <EquipmentImage uri={equipment.image_url} style={styles.hero} iconSize={56} />

      <View style={styles.titleBlock}>
        <View style={styles.badgesRow}>
          <EquipmentStatusBadge status={equipment.status} />
          {equipment.category ? (
            <View style={[styles.categoryChip, { backgroundColor: theme.neutralMuted }]}>
              <Ionicons name="pricetag-outline" size={12} color={theme.textSecondary} />
              <Text style={[styles.categoryText, { color: theme.textSecondary }]}>
                {equipment.category}
              </Text>
            </View>
          ) : null}
        </View>

        <Text style={[styles.name, { color: theme.text }]}>{equipment.name}</Text>
        <Text style={[styles.description, { color: theme.textSecondary }]}>
          {equipment.description}
        </Text>
      </View>

      {activeLoan ? (
        <InlineMessage
          tone={activeLoan.status === 'aprobado' ? 'success' : 'warning'}
          title={
            activeLoan.status === 'aprobado' ? 'Préstamo activo' : 'Solicitud en revisión'
          }
          message={
            activeLoan.status === 'aprobado'
              ? `Ya tienes este equipo prestado. Devuélvelo antes del ${formatDate(activeLoan.due_date)}.`
              : `Ya solicitaste este equipo. Está pendiente de aprobación hasta el ${formatDate(activeLoan.due_date)}.`
          }
          actionLabel="Ver mis préstamos"
          onAction={() => router.replace('/my-loans' as Href)}
        />
      ) : !available ? (
        <InlineMessage
          tone="warning"
          title="Equipo no disponible"
          message={
            equipment.status === 'prestado'
              ? 'Este equipo está prestado en este momento. Vuelve a intentarlo más tarde.'
              : 'Este equipo está en mantenimiento y no puede solicitarse.'
          }
          actionLabel="Volver al catálogo"
          onAction={() => router.back()}
        />
      ) : isAdmin ? (
        <InlineMessage
          tone="info"
          title="Vista de administrador"
          message="Puedes revisar las solicitudes de este equipo desde el panel de solicitudes."
          actionLabel="Ir a solicitudes"
          onAction={() => router.push('/admin' as Href)}
        />
      ) : (
        <View
          style={[
            styles.requestCard,
            { backgroundColor: theme.backgroundElement, borderColor: theme.border },
          ]}>
          <View style={styles.requestHeader}>
            <View style={[styles.requestIcon, { backgroundColor: theme.primaryMuted }]}>
              <Ionicons name="calendar-outline" size={20} color={theme.primary} />
            </View>
            <View style={styles.requestHeaderText}>
              <Text style={[styles.requestTitle, { color: theme.text }]}>Solicitar préstamo</Text>
              <Text style={[styles.requestSubtitle, { color: theme.textSecondary }]}>
                Elige cuánto tiempo necesitas el equipo.
              </Text>
            </View>
          </View>

          <View style={styles.chipsRow}>
            {DURATIONS.map((duration) => {
              const selected = duration.days === days;

              return (
                <Pressable
                  key={duration.days}
                  onPress={() => setDays(duration.days)}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  style={({ pressed }) => [
                    styles.durationChip,
                    {
                      backgroundColor: selected ? theme.primary : theme.background,
                      borderColor: selected ? theme.primary : theme.border,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}>
                  <Text
                    style={[
                      styles.durationText,
                      { color: selected ? theme.onPrimary : theme.textSecondary },
                    ]}>
                    {duration.label}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <View style={[styles.dueCard, { backgroundColor: theme.background }]}>
            <View style={styles.dueRow}>
              <Text style={[styles.dueLabel, { color: theme.textSecondary }]}>
                Fecha de devolución
              </Text>
              <Text style={[styles.dueValue, { color: theme.primary }]}>{formatDate(dueDate)}</Text>
            </View>
            <Text style={[styles.dueHint, { color: theme.textSecondary }]}>
              Hoy es {formatDate(todayISO())}. La solicitud queda sujeta a aprobación.
            </Text>
          </View>

          <TextField
            label="Notas (opcional)"
            placeholder="Ej. La usaré para la práctica de circuitos del jueves."
            value={notes}
            onChangeText={setNotes}
            icon="document-text-outline"
            multiline
            maxLength={300}
            editable={!submitting}
          />

          {submitError ? <InlineMessage tone="danger" message={submitError} /> : null}

          <Button
            title="Enviar solicitud"
            onPress={handleRequest}
            icon="send-outline"
            loading={submitting}
          />

          <Text style={[styles.disclaimer, { color: theme.textSecondary }]}>
            Al enviar la solicitud aceptas devolver el equipo en la fecha indicada.
          </Text>
        </View>
      )}

      {profile?.role === 'estudiante' ? (
        <View style={[styles.footerNote, { borderColor: theme.border }]}>
          <Ionicons name="information-circle-outline" size={16} color={theme.textSecondary} />
          <Text style={[styles.footerText, { color: theme.textSecondary }]}>
            El administrador revisará tu solicitud y te avisará cuando sea aprobada.
          </Text>
        </View>
      ) : null}

      <ConfirmDialog
        visible={requestSent}
        title="Solicitud enviada"
        message="Tu solicitud quedó pendiente de aprobación. Puedes seguir su estado en «Mis préstamos»."
        confirmLabel="Ver mis préstamos"
        cancelLabel="Seguir explorando"
        onConfirm={() => {
          setRequestSent(false);
          router.replace('/my-loans' as Href);
        }}
        onCancel={() => {
          setRequestSent(false);
          router.back();
        }}
      />
    </Screen>
  );
}

function BackButton() {
  const theme = useTheme();

  return (
    <Pressable
      onPress={() => router.back()}
      accessibilityLabel="Volver"
      hitSlop={8}
      style={({ pressed }) => [
        styles.backButton,
        { backgroundColor: theme.backgroundElement, borderColor: theme.border },
        pressed && styles.pressed,
      ]}>
      <Ionicons name="arrow-back" size={20} color={theme.text} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  content: {
    gap: Spacing.three,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
  },
  topTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  topSpacer: {
    width: 40,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: Radii.full,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  hero: {
    width: '100%',
    height: 210,
    borderRadius: Radii.lg,
  },
  titleBlock: {
    gap: Spacing.two,
  },
  badgesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: Spacing.two,
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.one,
    borderRadius: 999,
    paddingHorizontal: Spacing.two,
    paddingVertical: 4,
  },
  categoryText: {
    fontSize: 11,
    fontWeight: '600',
  },
  name: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
    lineHeight: 30,
  },
  description: {
    fontSize: 14,
    lineHeight: 21,
  },
  requestCard: {
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.three,
    gap: Spacing.three,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
  },
  requestIcon: {
    width: 40,
    height: 40,
    borderRadius: Radii.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  requestHeaderText: {
    flex: 1,
    gap: 1,
  },
  requestTitle: {
    fontSize: 16,
    fontWeight: '800',
  },
  requestSubtitle: {
    fontSize: 12,
  },
  chipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.two,
  },
  durationChip: {
    borderWidth: 1,
    borderRadius: 999,
    paddingHorizontal: Spacing.three,
    paddingVertical: 8,
  },
  durationText: {
    fontSize: 12,
    fontWeight: '700',
  },
  dueCard: {
    borderRadius: Radii.md,
    padding: Spacing.three,
    gap: Spacing.one,
  },
  dueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: Spacing.two,
  },
  dueLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  dueValue: {
    fontSize: 14,
    fontWeight: '800',
  },
  dueHint: {
    fontSize: 11,
    lineHeight: 16,
  },
  disclaimer: {
    fontSize: 11,
    lineHeight: 16,
    textAlign: 'center',
  },
  footerNote: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.two,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: Spacing.three,
  },
  footerText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 18,
  },
  pressed: {
    opacity: 0.7,
  },
});
