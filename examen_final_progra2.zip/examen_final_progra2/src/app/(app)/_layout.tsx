import { Redirect, Stack } from 'expo-router';

import { LoadingView } from '@/components/ui/loading-view';
import { useAuth } from '@/context/auth-context';
import { useTheme } from '@/hooks/use-theme';

export default function AppLayout() {
  const { session, initializing, profile, profileError } = useAuth();
  const theme = useTheme();

  if (initializing) {
    return <LoadingView label="Cargando sesión..." />;
  }

  if (!session) {
    return <Redirect href="/login" />;
  }

  if (!profile && !profileError) {
    return <LoadingView label="Cargando tu perfil..." />;
  }

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: theme.background },
      }}>
      <Stack.Screen name="(tabs)" />
      <Stack.Screen
        name="equipment/[id]"
        options={{
          animation: 'slide_from_right',
          contentStyle: { backgroundColor: theme.background },
        }}
      />
    </Stack>
  );
}
