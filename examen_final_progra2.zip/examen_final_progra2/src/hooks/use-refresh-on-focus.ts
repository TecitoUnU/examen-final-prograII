import { useFocusEffect } from 'expo-router';
import { useCallback, useRef } from 'react';

/**
 * Refresca datos cuando la pantalla vuelve a estar visible, sin duplicar la
 * carga inicial que ya hace `useQuery`.
 */
export function useRefreshOnFocus(refresh: () => void) {
  const firstFocus = useRef(true);

  useFocusEffect(
    useCallback(() => {
      if (firstFocus.current) {
        firstFocus.current = false;
        return;
      }

      refresh();
    }, [refresh])
  );
}
