import { useCallback, useEffect, useRef, useState } from 'react';

import { getErrorMessage } from '@/lib/errors';

type Mode = 'initial' | 'refresh' | 'silent';

/**
 * Pequeño hook para consultas con estados de carga, error y refresco.
 * `loader` debe ser estable (useCallback) para evitar bucles.
 */
export function useQuery<T>(loader: () => Promise<T>) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const requestId = useRef(0);

  const run = useCallback(
    async (mode: Mode = 'initial') => {
      const id = ++requestId.current;

      if (mode === 'initial') setLoading(true);
      if (mode === 'refresh') setRefreshing(true);
      setError(null);

      try {
        const result = await loader();
        if (requestId.current === id) {
          setData(result);
        }
      } catch (caught) {
        if (requestId.current === id) {
          setError(getErrorMessage(caught));
        }
      } finally {
        if (requestId.current === id) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    },
    [loader]
  );

  useEffect(() => {
    run('initial');

    return () => {
      requestId.current += 1;
    };
  }, [run]);

  const refresh = useCallback(() => run('refresh'), [run]);
  const reload = useCallback(() => run('silent'), [run]);

  return { data, loading, refreshing, error, refresh, reload, setData };
}
