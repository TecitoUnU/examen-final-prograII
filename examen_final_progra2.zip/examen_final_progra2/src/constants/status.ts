import type { EquipmentStatus, LoanStatus } from '@/types';

export type StatusTone = 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'neutral';

export const LOAN_STATUS_LABEL: Record<LoanStatus, string> = {
  pendiente: 'Pendiente',
  aprobado: 'Aprobado',
  rechazado: 'Rechazado',
  devuelto: 'Devuelto',
};

export const LOAN_STATUS_TONE: Record<LoanStatus, StatusTone> = {
  pendiente: 'warning',
  aprobado: 'primary',
  rechazado: 'danger',
  devuelto: 'success',
};

export const LOAN_STATUS_OPTIONS: { value: LoanStatus | 'todos'; label: string }[] = [
  { value: 'todos', label: 'Todos' },
  { value: 'pendiente', label: 'Pendientes' },
  { value: 'aprobado', label: 'Aprobados' },
  { value: 'devuelto', label: 'Devueltos' },
  { value: 'rechazado', label: 'Rechazados' },
];

export const EQUIPMENT_STATUS_LABEL: Record<EquipmentStatus, string> = {
  disponible: 'Disponible',
  prestado: 'Prestado',
  mantenimiento: 'Mantenimiento',
};

export const EQUIPMENT_STATUS_TONE: Record<EquipmentStatus, StatusTone> = {
  disponible: 'success',
  prestado: 'warning',
  mantenimiento: 'neutral',
};

export const EQUIPMENT_STATUS_OPTIONS: { value: EquipmentStatus | 'todos'; label: string }[] = [
  { value: 'todos', label: 'Todos' },
  { value: 'disponible', label: 'Disponibles' },
  { value: 'prestado', label: 'Prestados' },
  { value: 'mantenimiento', label: 'Mantenimiento' },
];

export const USER_ROLE_LABEL = {
  estudiante: 'Estudiante',
  administrador: 'Administrador',
} as const;
