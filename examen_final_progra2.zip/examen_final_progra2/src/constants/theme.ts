/**
 * Design tokens for the laboratory equipment loan app.
 *
 * Colors are defined for light and dark mode. Every key must exist in both
 * palettes because `ThemeColor` is derived from their intersection.
 */

import '@/global.css';

import { Platform } from 'react-native';

export const Colors = {
  light: {
    text: '#0F172A',
    textSecondary: '#64748B',
    background: '#F6F8FB',
    backgroundElement: '#FFFFFF',
    backgroundSelected: '#EEF2F7',
    border: '#E2E8F0',
    primary: '#2563EB',
    onPrimary: '#FFFFFF',
    primaryMuted: '#DBEAFE',
    success: '#15803D',
    successMuted: '#DCFCE7',
    warning: '#B45309',
    warningMuted: '#FEF3C7',
    danger: '#DC2626',
    dangerMuted: '#FEE2E2',
    info: '#0E7490',
    infoMuted: '#CFFAFE',
    neutralMuted: '#F1F5F9',
    overlay: 'rgba(15, 23, 42, 0.45)',
  },
  dark: {
    text: '#F8FAFC',
    textSecondary: '#94A3B8',
    background: '#0B1220',
    backgroundElement: '#131C2E',
    backgroundSelected: '#1E293B',
    border: '#22304A',
    primary: '#3B82F6',
    onPrimary: '#FFFFFF',
    primaryMuted: '#1E3A8A',
    success: '#4ADE80',
    successMuted: '#14532D',
    warning: '#FBBF24',
    warningMuted: '#78350F',
    danger: '#F87171',
    dangerMuted: '#7F1D1D',
    info: '#22D3EE',
    infoMuted: '#164E63',
    neutralMuted: '#1E293B',
    overlay: 'rgba(2, 6, 23, 0.7)',
  },
} as const;

export type ThemeColor = keyof typeof Colors.light & keyof typeof Colors.dark;

export const Fonts = Platform.select({
  ios: {
    /** iOS `UIFontDescriptorSystemDesignDefault` */
    sans: 'system-ui',
    /** iOS `UIFontDescriptorSystemDesignSerif` */
    serif: 'ui-serif',
    /** iOS `UIFontDescriptorSystemDesignRounded` */
    rounded: 'ui-rounded',
    /** iOS `UIFontDescriptorSystemDesignMonospaced` */
    mono: 'ui-monospace',
  },
  default: {
    sans: 'normal',
    serif: 'serif',
    rounded: 'normal',
    mono: 'monospace',
  },
  web: {
    sans: 'var(--font-display)',
    serif: 'var(--font-serif)',
    rounded: 'var(--font-rounded)',
    mono: 'var(--font-mono)',
  },
});

export const Spacing = {
  half: 2,
  one: 4,
  two: 8,
  three: 16,
  four: 24,
  five: 32,
  six: 64,
} as const;

export const Radii = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
} as const;

export const BottomTabInset = Platform.select({ ios: 50, android: 80 }) ?? 0;
export const MaxContentWidth = 800;
