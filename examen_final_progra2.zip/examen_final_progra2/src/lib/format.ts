const MONTHS = [
  'ene',
  'feb',
  'mar',
  'abr',
  'may',
  'jun',
  'jul',
  'ago',
  'sep',
  'oct',
  'nov',
  'dic',
];

function pad(value: number) {
  return value.toString().padStart(2, '0');
}

/** Fecha local en formato YYYY-MM-DD (sin desfase de zona horaria). */
export function toISODate(date: Date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function todayISO() {
  return toISODate(new Date());
}

/** Suma días a la fecha de hoy y devuelve YYYY-MM-DD. */
export function addDaysISO(days: number) {
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  date.setDate(date.getDate() + days);
  return toISODate(date);
}

function parseDateOnly(value: string) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, (month ?? 1) - 1, day ?? 1, 12, 0, 0);
}

/** Formatea `YYYY-MM-DD` o un timestamp ISO como "12 nov 2026". */
export function formatDate(value?: string | null) {
  if (!value) return '—';

  const date = value.length <= 10 ? parseDateOnly(value) : new Date(value);
  if (Number.isNaN(date.getTime())) return '—';

  return `${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`;
}

/** Formatea un timestamp como "12 nov 2026 · 14:30". */
export function formatDateTime(value?: string | null) {
  if (!value) return '—';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';

  return `${formatDate(value)} · ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function formatIsoDay(value: Date) {
  return toISODate(value);
}

/** true si la fecha límite (YYYY-MM-DD) ya pasó. */
export function isPastDue(dueDate?: string | null) {
  if (!dueDate) return false;
  return dueDate < todayISO();
}

export function initials(name?: string | null) {
  if (!name) return '?';

  return (
    name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part.charAt(0).toUpperCase())
      .join('') || '?'
  );
}

export function firstName(name?: string | null) {
  return name?.trim().split(/\s+/)[0] ?? '';
}

export function plural(count: number, singular: string, pluralForm: string) {
  return count === 1 ? singular : pluralForm;
}
