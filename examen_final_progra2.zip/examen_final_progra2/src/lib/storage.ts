import { File } from 'expo-file-system';
import { Platform } from 'react-native';

import { supabase } from './supabase';

const AVATAR_BUCKET = 'avatars';

async function readImage(uri: string): Promise<Blob | ArrayBuffer> {
  if (Platform.OS === 'web') {
    const response = await fetch(uri);
    return response.blob();
  }

  const file = new File(uri);
  return file.arrayBuffer();
}

/**
 * Sube la foto de perfil al bucket `avatars` y devuelve su URL pública.
 * La ruta `avatars/<user_id>/...` coincide con las políticas RLS de Storage.
 */
export async function uploadAvatar(userId: string, uri: string): Promise<string> {
  const extension = uri.split('.').pop()?.split('?')[0]?.toLowerCase();
  const safeExtension = extension && extension.length <= 5 ? extension : 'jpg';
  const path = `${userId}/avatar-${Date.now()}.${safeExtension}`;
  const body = await readImage(uri);

  const { error } = await supabase.storage.from(AVATAR_BUCKET).upload(path, body, {
    contentType: `image/${safeExtension === 'jpg' ? 'jpeg' : safeExtension}`,
    upsert: true,
  });

  if (error) throw error;

  const { data } = supabase.storage.from(AVATAR_BUCKET).getPublicUrl(path);
  return data.publicUrl;
}
