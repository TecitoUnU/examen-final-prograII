type ErrorLike = {
  message?: string;
  code?: string;
  details?: string;
  hint?: string;
  status?: number;
};

const TRANSLATIONS: { match: RegExp; message: string }[] = [
  {
    match: /invalid login credentials/i,
    message: 'Correo o contraseña incorrectos. Verifica tus datos e inténtalo de nuevo.',
  },
  {
    match: /email not confirmed/i,
    message:
      'Debes confirmar tu correo electrónico antes de iniciar sesión. Revisa tu bandeja de entrada.',
  },
  {
    match: /user already registered|already been registered/i,
    message: 'Ya existe una cuenta con este correo electrónico.',
  },
  {
    match: /password should be at least|password.*at least 6/i,
    message: 'La contraseña debe tener al menos 6 caracteres.',
  },
  {
    match: /profiles_carnet_unique|duplicate key.*carnet/i,
    message: 'El carnet ya está registrado en otra cuenta.',
  },
  {
    match: /loans_one_active_per_user_equipment|duplicate key.*loans.*user/i,
    message: 'Ya tienes una solicitud activa para este equipo.',
  },
  {
    match: /loans_one_approved_per_equipment|duplicate key.*loans.*equipment/i,
    message: 'Este equipo ya tiene un préstamo aprobado.',
  },
  {
    match: /la fecha de devolución no puede ser anterior a hoy/i,
    message: 'La fecha de devolución no puede ser anterior a hoy.',
  },
  {
    match: /el equipo no está disponible para préstamo/i,
    message: 'Este equipo ya no está disponible para préstamo.',
  },
  {
    match: /el equipo ya no está disponible/i,
    message: 'Este equipo ya no está disponible.',
  },
  {
    match: /solo se puede aprobar una solicitud pendiente/i,
    message: 'Solo se puede aprobar una solicitud pendiente.',
  },
  {
    match: /solo se puede rechazar una solicitud pendiente/i,
    message: 'Solo se puede rechazar una solicitud pendiente.',
  },
  {
    match: /solo se puede devolver un préstamo aprobado/i,
    message: 'Solo se puede marcar como devuelto un préstamo aprobado.',
  },
  {
    match: /invalid api key/i,
    message:
      'La clave de Supabase no es válida. Revisa EXPO_PUBLIC_SUPABASE_ANON_KEY en tu archivo .env y confirma que pertenece al mismo proyecto.',
  },
  {
    match: /network request failed|failed to fetch|fetch failed|networkerror/i,
    message:
      'No se pudo conectar con el servidor. Verifica tu conexión a internet e inténtalo de nuevo.',
  },
  {
    match: /jwt expired|invalid jwt|token has expired/i,
    message: 'Tu sesión expiró. Vuelve a iniciar sesión.',
  },
  {
    match: /row-level security|permission denied|new row violates row-level security/i,
    message: 'No tienes permisos para realizar esta acción.',
  },
  {
    match: /relation .* does not exist|could not find the table/i,
    message:
      'La base de datos aún no está configurada. Ejecuta el archivo supabase/schema.sql en Supabase.',
  },
  {
    match: /function .* does not exist/i,
    message:
      'Falta una función en la base de datos. Vuelve a ejecutar supabase/schema.sql en Supabase.',
  },
  {
    match: /bucket not found/i,
    message: 'El almacenamiento de fotos no está configurado. Ejecuta supabase/schema.sql.',
  },
];

/**
 * Convierte errores de Supabase/Auth en mensajes claros en español.
 */
export function getErrorMessage(error: unknown): string {
  if (!error) return 'Ocurrió un error inesperado. Inténtalo de nuevo.';

  if (typeof error === 'string') return error;

  const parsed = error as ErrorLike;
  const raw = parsed.message?.trim();

  if (raw) {
    for (const translation of TRANSLATIONS) {
      if (translation.match.test(raw)) {
        return translation.message;
      }
    }

    return raw;
  }

  if (error instanceof Error) {
    return error.message || 'Ocurrió un error inesperado. Inténtalo de nuevo.';
  }

  return 'Ocurrió un error inesperado. Inténtalo de nuevo.';
}

export function isUniqueViolation(error: unknown) {
  return (error as ErrorLike | null)?.code === '23505';
}
