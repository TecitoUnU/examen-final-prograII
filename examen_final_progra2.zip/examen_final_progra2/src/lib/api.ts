import type {
  Equipment,
  EquipmentReportRow,
  Loan,
  LoanStatus,
  LoanWithRelations,
  Profile,
  StudentSummary,
} from '@/types';

import { supabase } from './supabase';

const LOAN_RELATIONS =
  '*, equipment(*), student:profiles!loans_user_id_fkey(id, full_name, carnet, carrera, avatar_url)';

export async function getEquipment(): Promise<Equipment[]> {
  const { data, error } = await supabase.from('equipment').select('*').order('name');
  if (error) throw error;
  return (data ?? []) as Equipment[];
}

export async function getEquipmentById(id: string): Promise<Equipment> {
  const { data, error } = await supabase.from('equipment').select('*').eq('id', id).single();
  if (error) throw error;
  return data as Equipment;
}

export async function getMyLoans(userId: string): Promise<LoanWithRelations[]> {
  const { data, error } = await supabase
    .from('loans')
    .select(LOAN_RELATIONS)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return (data ?? []) as unknown as LoanWithRelations[];
}

export async function getAllLoans(): Promise<LoanWithRelations[]> {
  const { data, error } = await supabase
    .from('loans')
    .select(LOAN_RELATIONS)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return (data ?? []) as unknown as LoanWithRelations[];
}

export async function getActiveLoanForEquipment(
  userId: string,
  equipmentId: string
): Promise<Loan | null> {
  const { data, error } = await supabase
    .from('loans')
    .select('*')
    .eq('user_id', userId)
    .eq('equipment_id', equipmentId)
    .in('status', ['pendiente', 'aprobado'])
    .maybeSingle();

  if (error) throw error;
  return (data as Loan | null) ?? null;
}

export async function requestLoan(input: {
  userId: string;
  equipmentId: string;
  dueDate: string;
  notes?: string | null;
}): Promise<Loan> {
  const { data, error } = await supabase
    .from('loans')
    .insert({
      user_id: input.userId,
      equipment_id: input.equipmentId,
      due_date: input.dueDate,
      notes: input.notes?.trim() ? input.notes.trim() : null,
    })
    .select('*')
    .single();

  if (error) throw error;
  return data as Loan;
}

export async function updateLoanStatus(input: {
  loanId: string;
  status: LoanStatus;
  reviewerId: string;
}): Promise<Loan> {
  const payload: { status: LoanStatus; reviewed_by?: string } = { status: input.status };

  if (input.status === 'aprobado' || input.status === 'rechazado') {
    payload.reviewed_by = input.reviewerId;
  }

  const { data, error } = await supabase
    .from('loans')
    .update(payload)
    .eq('id', input.loanId)
    .select('*')
    .single();

  if (error) throw error;
  return data as Loan;
}

export async function getEquipmentReport(): Promise<EquipmentReportRow[]> {
  const { data, error } = await supabase
    .from('equipment_request_report')
    .select('*')
    .order('total_requests', { ascending: false })
    .order('name', { ascending: true });

  if (error) throw error;
  return (data ?? []) as EquipmentReportRow[];
}

export async function updateOwnProfile(input: {
  userId: string;
  fullName: string;
  carrera: string;
  avatarUrl: string | null;
}): Promise<Profile> {
  const { data, error } = await supabase
    .from('profiles')
    .update({
      full_name: input.fullName,
      carrera: input.carrera,
      avatar_url: input.avatarUrl,
    })
    .eq('id', input.userId)
    .select('*')
    .single();

  if (error) throw error;
  return data as Profile;
}

export async function getStudentSummary(userId: string): Promise<StudentSummary | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, carnet, carrera, avatar_url')
    .eq('id', userId)
    .maybeSingle();

  if (error) throw error;
  return (data as StudentSummary | null) ?? null;
}
