import type { ComponentProps } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/use-theme';

type StatCardProps = {
  icon: ComponentProps<typeof Ionicons>['name'];
  label: string;
  value: number;
  tone: string;
  background: string;
};

export function StatCard({ icon, label, value, tone, background }: StatCardProps) {
  const theme = useTheme();

  return (
    <View style={[styles.card, { backgroundColor: background }]}>
      <Ionicons name={icon} size={17} color={tone} />
      <Text style={[styles.value, { color: tone }]}>{value}</Text>
      <Text style={[styles.label, { color: theme.textSecondary }]} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    borderRadius: Radii.md,
    paddingVertical: Spacing.two + 2,
    paddingHorizontal: Spacing.two,
    alignItems: 'flex-start',
    gap: 1,
  },
  value: {
    fontSize: 20,
    fontWeight: '800',
    lineHeight: 24,
  },
  label: {
    fontSize: 10,
    fontWeight: '700',
  },
});
