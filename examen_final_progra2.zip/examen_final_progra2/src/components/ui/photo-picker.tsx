import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Alert, Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/use-theme';

import { Avatar } from './avatar';
import { Button } from './button';

type PhotoPickerProps = {
  uri?: string | null;
  name?: string | null;
  onChange: (uri: string | null) => void;
  disabled?: boolean;
};

export function PhotoPicker({ uri, name, onChange, disabled = false }: PhotoPickerProps) {
  const theme = useTheme();

  const pickImage = async () => {
    if (disabled) return;

    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) {
      Alert.alert(
        'Permiso requerido',
        'Para elegir una foto necesitamos acceso a tu galería.',
        [
          { text: 'Cancelar', style: 'cancel' },
          ...(Platform.OS !== 'web'
            ? [{ text: 'Abrir ajustes', onPress: () => Linking.openSettings() }]
            : []),
        ]
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });

    if (!result.canceled && result.assets[0]?.uri) {
      onChange(result.assets[0].uri);
    }
  };

  return (
    <View style={styles.container}>
      <Pressable
        onPress={pickImage}
        disabled={disabled}
        accessibilityRole="button"
        accessibilityLabel="Elegir foto de perfil"
        style={({ pressed }) => [pressed && styles.pressed]}>
        <Avatar uri={uri} name={name} size={88} />
        <View
          style={[
            styles.cameraBadge,
            { backgroundColor: theme.primary, borderColor: theme.backgroundElement },
          ]}>
          <Ionicons name="camera" size={15} color={theme.onPrimary} />
        </View>
      </Pressable>

      <View style={styles.content}>
        <Text style={[styles.title, { color: theme.text }]}>Foto de perfil</Text>
        <Text style={[styles.hint, { color: theme.textSecondary }]}>
          Opcional. Una foto ayuda a identificarte en el laboratorio.
        </Text>
        <View style={styles.actions}>
          <Button
            title={uri ? 'Cambiar foto' : 'Elegir foto'}
            onPress={pickImage}
            variant="secondary"
            size="sm"
            icon="image-outline"
            fullWidth={false}
            disabled={disabled}
          />
          {uri ? (
            <Button
              title="Quitar"
              onPress={() => onChange(null)}
              variant="ghost"
              size="sm"
              icon="trash-outline"
              fullWidth={false}
              disabled={disabled}
            />
          ) : null}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.three,
  },
  cameraBadge: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 30,
    height: 30,
    borderRadius: Radii.full,
    borderWidth: 3,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    gap: Spacing.one,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
  },
  hint: {
    fontSize: 12,
    lineHeight: 17,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: Spacing.two,
    marginTop: Spacing.one,
  },
  pressed: {
    opacity: 0.85,
  },
});
