import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/use-theme';

/**
 * Aviso que se muestra cuando faltan las variables de entorno de Supabase.
 */
export function ConfigWarning() {
  const theme = useTheme();

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: theme.warningMuted, borderColor: theme.warning },
      ]}>
      <View style={styles.header}>
        <Ionicons name="warning-outline" size={22} color={theme.warning} />
        <Text style={[styles.title, { color: theme.warning }]}>Supabase no está configurado</Text>
      </View>
      <Text style={[styles.text, { color: theme.warning }]}>
        Crea un archivo <Text style={styles.mono}>.env</Text> (o{' '}
        <Text style={styles.mono}>.env.local</Text>) en la raíz del proyecto con estas variables y
        reinicia la app:
      </Text>
      <View style={[styles.code, { backgroundColor: theme.backgroundElement }]}>
        <Text style={[styles.mono, { color: theme.text }]}>
          EXPO_PUBLIC_SUPABASE_URL=...{'\n'}
          EXPO_PUBLIC_SUPABASE_ANON_KEY=...
        </Text>
      </View>
      <Text style={[styles.text, { color: theme.warning }]}>
        Consulta <Text style={styles.mono}>GUIA_SUPABASE.md</Text> para ejecutar el esquema SQL.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderRadius: Radii.md,
    padding: Spacing.three,
    gap: Spacing.two,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
  },
  title: {
    flex: 1,
    fontSize: 15,
    fontWeight: '700',
  },
  text: {
    fontSize: 13,
    lineHeight: 19,
  },
  code: {
    borderRadius: Radii.sm,
    padding: Spacing.two,
  },
  mono: {
    fontFamily: 'monospace',
    fontSize: 12,
  },
});
