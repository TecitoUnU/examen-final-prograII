import type { ComponentProps } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import type { StatusTone } from '@/constants/status';
import { useTheme } from '@/hooks/use-theme';

type InlineMessageProps = {
  tone?: StatusTone;
  title?: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  style?: StyleProp<ViewStyle>;
};

const ICONS: Record<StatusTone, ComponentProps<typeof Ionicons>['name']> = {
  primary: 'information-circle-outline',
  success: 'checkmark-circle-outline',
  warning: 'alert-circle-outline',
  danger: 'close-circle-outline',
  info: 'information-circle-outline',
  neutral: 'information-circle-outline',
};

export function InlineMessage({
  tone = 'info',
  title,
  message,
  actionLabel,
  onAction,
  style,
}: InlineMessageProps) {
  const theme = useTheme();

  const palette = {
    primary: { fg: theme.primary, bg: theme.primaryMuted },
    success: { fg: theme.success, bg: theme.successMuted },
    warning: { fg: theme.warning, bg: theme.warningMuted },
    danger: { fg: theme.danger, bg: theme.dangerMuted },
    info: { fg: theme.info, bg: theme.infoMuted },
    neutral: { fg: theme.textSecondary, bg: theme.neutralMuted },
  }[tone];

  return (
    <View style={[styles.container, { backgroundColor: palette.bg }, style]}>
      <Ionicons name={ICONS[tone]} size={20} color={palette.fg} style={styles.icon} />
      <View style={styles.content}>
        {title ? <Text style={[styles.title, { color: palette.fg }]}>{title}</Text> : null}
        <Text style={[styles.message, { color: palette.fg }]}>{message}</Text>
        {actionLabel && onAction ? (
          <Pressable
            onPress={onAction}
            hitSlop={8}
            style={({ pressed }) => [styles.action, pressed && styles.pressed]}>
            <Text style={[styles.actionLabel, { color: palette.fg }]}>{actionLabel}</Text>
            <Ionicons name="arrow-forward" size={14} color={palette.fg} />
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderRadius: Radii.md,
    padding: Spacing.three,
    gap: Spacing.two,
  },
  icon: {
    marginTop: 1,
  },
  content: {
    flex: 1,
    gap: Spacing.half,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
  },
  message: {
    fontSize: 13,
    lineHeight: 19,
  },
  action: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: Spacing.one,
    marginTop: Spacing.one,
  },
  actionLabel: {
    fontSize: 13,
    fontWeight: '700',
  },
  pressed: {
    opacity: 0.7,
  },
});
