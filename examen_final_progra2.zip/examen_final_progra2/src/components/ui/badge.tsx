import type { ComponentProps } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View, type StyleProp, type ViewStyle } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import type { StatusTone } from '@/constants/status';
import {
  EQUIPMENT_STATUS_LABEL,
  EQUIPMENT_STATUS_TONE,
  LOAN_STATUS_LABEL,
  LOAN_STATUS_TONE,
} from '@/constants/status';
import { useTheme } from '@/hooks/use-theme';
import type { EquipmentStatus, LoanStatus } from '@/types';

type BadgeProps = {
  label: string;
  tone?: StatusTone;
  icon?: ComponentProps<typeof Ionicons>['name'];
  small?: boolean;
  style?: StyleProp<ViewStyle>;
};

export function Badge({ label, tone = 'neutral', icon, small = false, style }: BadgeProps) {
  const theme = useTheme();

  const palette = {
    primary: { fg: theme.primary, bg: theme.primaryMuted },
    success: { fg: theme.success, bg: theme.successMuted },
    warning: { fg: theme.warning, bg: theme.warningMuted },
    danger: { fg: theme.danger, bg: theme.dangerMuted },
    info: { fg: theme.info, bg: theme.infoMuted },
    neutral: { fg: theme.textSecondary, bg: theme.neutralMuted },
  }[tone];

  return (
    <View
      style={[
        styles.badge,
        small && styles.badgeSmall,
        { backgroundColor: palette.bg },
        style,
      ]}>
      {icon ? <Ionicons name={icon} size={small ? 11 : 13} color={palette.fg} /> : null}
      <Text style={[styles.label, small && styles.labelSmall, { color: palette.fg }]}>{label}</Text>
    </View>
  );
}

export function LoanStatusBadge({ status, small }: { status: LoanStatus; small?: boolean }) {
  return <Badge label={LOAN_STATUS_LABEL[status]} tone={LOAN_STATUS_TONE[status]} small={small} />;
}

export function EquipmentStatusBadge({
  status,
  small,
}: {
  status: EquipmentStatus;
  small?: boolean;
}) {
  return (
    <Badge label={EQUIPMENT_STATUS_LABEL[status]} tone={EQUIPMENT_STATUS_TONE[status]} small={small} />
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: Spacing.one,
    borderRadius: Radii.full,
    paddingHorizontal: Spacing.two,
    paddingVertical: 3,
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  label: {
    fontSize: 12,
    fontWeight: '700',
  },
  labelSmall: {
    fontSize: 10,
  },
});
