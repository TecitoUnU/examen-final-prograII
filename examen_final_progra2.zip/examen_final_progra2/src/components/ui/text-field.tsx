import type { ComponentProps } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';
import {
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type TextInputProps,
  type TextStyle,
  type ViewStyle,
} from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/use-theme';

type TextFieldProps = TextInputProps & {
  label?: string;
  error?: string | null;
  hint?: string;
  icon?: ComponentProps<typeof Ionicons>['name'];
  rightIcon?: ComponentProps<typeof Ionicons>['name'];
  onRightIconPress?: () => void;
  containerStyle?: StyleProp<ViewStyle>;
  inputStyle?: StyleProp<TextStyle>;
};

export function TextField({
  label,
  error,
  hint,
  icon,
  rightIcon,
  onRightIconPress,
  containerStyle,
  inputStyle,
  onFocus,
  onBlur,
  multiline,
  ...rest
}: TextFieldProps) {
  const theme = useTheme();
  const [focused, setFocused] = useState(false);

  const borderColor = error ? theme.danger : focused ? theme.primary : theme.border;

  return (
    <View style={[styles.container, containerStyle]}>
      {label ? <Text style={[styles.label, { color: theme.text }]}>{label}</Text> : null}

      <View
        style={[
          styles.inputWrapper,
          {
            backgroundColor: theme.backgroundElement,
            borderColor,
          },
          multiline && styles.multilineWrapper,
        ]}>
        {icon ? (
          <Ionicons name={icon} size={19} color={theme.textSecondary} style={styles.leftIcon} />
        ) : null}

        <TextInput
          {...rest}
          multiline={multiline}
          placeholderTextColor={theme.textSecondary}
          selectionColor={theme.primary}
          onFocus={(event) => {
            setFocused(true);
            onFocus?.(event);
          }}
          onBlur={(event) => {
            setFocused(false);
            onBlur?.(event);
          }}
          style={[
            styles.input,
            { color: theme.text },
            multiline && styles.multilineInput,
            inputStyle,
          ]}
        />

        {rightIcon ? (
          <Pressable
            onPress={onRightIconPress}
            hitSlop={10}
            disabled={!onRightIconPress}
            style={({ pressed }) => [styles.rightIcon, pressed && styles.pressed]}>
            <Ionicons name={rightIcon} size={20} color={theme.textSecondary} />
          </Pressable>
        ) : null}
      </View>

      {error ? (
        <Text style={[styles.helper, { color: theme.danger }]}>{error}</Text>
      ) : hint ? (
        <Text style={[styles.helper, { color: theme.textSecondary }]}>{hint}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: Spacing.two,
  },
  label: {
    fontSize: 13,
    fontWeight: '700',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: Radii.md,
    minHeight: 48,
    paddingHorizontal: Spacing.three,
    gap: Spacing.two,
  },
  multilineWrapper: {
    alignItems: 'flex-start',
    paddingVertical: Spacing.two,
  },
  leftIcon: {
    marginTop: -1,
  },
  input: {
    flex: 1,
    fontSize: 15,
    paddingVertical: 0,
    minHeight: 22,
  },
  multilineInput: {
    minHeight: 88,
    textAlignVertical: 'top',
    paddingTop: Spacing.one,
  },
  rightIcon: {
    padding: Spacing.half,
  },
  helper: {
    fontSize: 12,
    lineHeight: 17,
  },
  pressed: {
    opacity: 0.6,
  },
});
