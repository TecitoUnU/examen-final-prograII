import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/use-theme';

export type FilterOption<T extends string> = {
  value: T;
  label: string;
  count?: number;
};

type FilterChipsProps<T extends string> = {
  options: FilterOption<T>[];
  value: T;
  onChange: (value: T) => void;
};

export function FilterChips<T extends string>({ options, value, onChange }: FilterChipsProps<T>) {
  const theme = useTheme();

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.container}>
      {options.map((option) => {
        const active = option.value === value;

        return (
          <Pressable
            key={option.value}
            onPress={() => onChange(option.value)}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
            style={({ pressed }) => [
              styles.chip,
              {
                backgroundColor: active ? theme.primary : theme.backgroundElement,
                borderColor: active ? theme.primary : theme.border,
                opacity: pressed ? 0.8 : 1,
              },
            ]}>
            <Text
              style={[styles.label, { color: active ? theme.onPrimary : theme.textSecondary }]}>
              {option.label}
              {typeof option.count === 'number' ? ` (${option.count})` : ''}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: Spacing.two,
    paddingVertical: Spacing.one,
    paddingRight: Spacing.three,
  },
  chip: {
    borderWidth: 1,
    borderRadius: Radii.full,
    paddingHorizontal: Spacing.three,
    paddingVertical: 7,
  },
  label: {
    fontSize: 12,
    fontWeight: '700',
  },
});
