import { Ionicons } from '@expo/vector-icons';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { useTheme } from '@/hooks/use-theme';
import type { Equipment } from '@/types';

import { EquipmentImage } from './equipment-image';
import { EquipmentStatusBadge } from './ui/badge';

type EquipmentCardProps = {
  equipment: Equipment;
  onPress: () => void;
};

export function EquipmentCard({ equipment, onPress }: EquipmentCardProps) {
  const theme = useTheme();
  const available = equipment.status === 'disponible';

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Ver ${equipment.name}`}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: theme.backgroundElement,
          borderColor: theme.border,
          opacity: pressed ? 0.85 : 1,
        },
      ]}>
      <EquipmentImage uri={equipment.image_url} style={styles.image} iconSize={28} />

      <View style={styles.content}>
        <View style={styles.topRow}>
          <Text style={[styles.name, { color: theme.text }]} numberOfLines={2}>
            {equipment.name}
          </Text>
          <EquipmentStatusBadge status={equipment.status} small />
        </View>

        {equipment.category ? (
          <Text style={[styles.category, { color: theme.primary }]} numberOfLines={1}>
            {equipment.category}
          </Text>
        ) : null}

        <Text style={[styles.description, { color: theme.textSecondary }]} numberOfLines={2}>
          {equipment.description}
        </Text>

        <View style={styles.footer}>
          <Text
            style={[
              styles.availability,
              { color: available ? theme.success : theme.textSecondary },
            ]}>
            {available ? 'Disponible para préstamo' : 'No disponible'}
          </Text>
          <View style={[styles.action, { backgroundColor: available ? theme.primaryMuted : theme.neutralMuted }]}>
            <Text
              style={[styles.actionText, { color: available ? theme.primary : theme.textSecondary }]}>
              {available ? 'Solicitar' : 'Ver'}
            </Text>
            <Ionicons
              name="chevron-forward"
              size={13}
              color={available ? theme.primary : theme.textSecondary}
            />
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    gap: Spacing.three,
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.two + 2,
  },
  image: {
    width: 94,
    height: 118,
    borderRadius: Radii.md,
  },
  content: {
    flex: 1,
    gap: 3,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.two,
  },
  name: {
    flex: 1,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  category: {
    fontSize: 12,
    fontWeight: '700',
  },
  description: {
    fontSize: 12,
    lineHeight: 17,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: Spacing.two,
    marginTop: 'auto',
    paddingTop: Spacing.one,
  },
  availability: {
    flex: 1,
    fontSize: 11,
    fontWeight: '600',
  },
  action: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: Spacing.two,
    paddingVertical: 4,
    borderRadius: Radii.full,
  },
  actionText: {
    fontSize: 11,
    fontWeight: '700',
  },
});
