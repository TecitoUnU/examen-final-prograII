import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { useTheme } from '@/hooks/use-theme';

type EquipmentImageProps = {
  uri?: string | null;
  style?: StyleProp<ViewStyle>;
  iconSize?: number;
};

export function EquipmentImage({ uri, style, iconSize = 30 }: EquipmentImageProps) {
  const theme = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: theme.primaryMuted }, style]}>
      {uri ? (
        <Image
          source={{ uri }}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          transition={150}
        />
      ) : (
        <Ionicons name="flask-outline" size={iconSize} color={theme.primary} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
