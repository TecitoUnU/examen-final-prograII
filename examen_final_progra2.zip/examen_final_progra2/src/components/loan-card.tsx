import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';

import { Radii, Spacing } from '@/constants/theme';
import { formatDate, isPastDue } from '@/lib/format';
import { useTheme } from '@/hooks/use-theme';
import type { LoanStatus, LoanWithRelations } from '@/types';

import { EquipmentImage } from './equipment-image';
import { Avatar } from './ui/avatar';
import { LoanStatusBadge } from './ui/badge';
import { Button } from './ui/button';

type LoanCardProps = {
  loan: LoanWithRelations;
  showStudent?: boolean;
  onApprove?: () => void;
  onReject?: () => void;
  onReturn?: () => void;
  busyAction?: LoanStatus | null;
};

export function LoanCard({
  loan,
  showStudent = false,
  onApprove,
  onReject,
  onReturn,
  busyAction = null,
}: LoanCardProps) {
  const theme = useTheme();
  const equipment = loan.equipment;
  const overdue = loan.status === 'aprobado' && isPastDue(loan.due_date);

  const hint = (() => {
    switch (loan.status) {
      case 'pendiente':
        return {
          icon: 'time-outline' as const,
          color: theme.warning,
          text: 'Esperando la revisión del administrador.',
        };
      case 'aprobado':
        return overdue
          ? {
              icon: 'alert-circle-outline' as const,
              color: theme.danger,
              text: `El plazo venció el ${formatDate(loan.due_date)}. Devuelve el equipo cuanto antes.`,
            }
          : {
              icon: 'checkmark-circle-outline' as const,
              color: theme.success,
              text: `Préstamo activo. Devolución antes del ${formatDate(loan.due_date)}.`,
            };
      case 'devuelto':
        return {
          icon: 'archive-outline' as const,
          color: theme.success,
          text: `Equipo devuelto el ${formatDate(loan.return_date)}.`,
        };
      case 'rechazado':
        return {
          icon: 'close-circle-outline' as const,
          color: theme.danger,
          text: 'La solicitud fue rechazada por el administrador.',
        };
      default:
        return null;
    }
  })();

  return (
    <View
      style={[
        styles.card,
        { backgroundColor: theme.backgroundElement, borderColor: theme.border },
      ]}>
      <View style={styles.header}>
        <EquipmentImage uri={equipment?.image_url} style={styles.image} iconSize={22} />

        <View style={styles.headerContent}>
          <Text style={[styles.name, { color: theme.text }]} numberOfLines={2}>
            {equipment?.name ?? 'Equipo eliminado'}
          </Text>
          <Text style={[styles.category, { color: theme.textSecondary }]} numberOfLines={1}>
            {equipment?.category ?? 'Equipo de laboratorio'}
          </Text>
          <LoanStatusBadge status={loan.status} small />
        </View>
      </View>

      {showStudent && loan.student ? (
        <View style={[styles.studentRow, { borderColor: theme.border }]}>
          <Avatar uri={loan.student.avatar_url} name={loan.student.full_name} size={30} />
          <View style={styles.studentContent}>
            <Text style={[styles.studentName, { color: theme.text }]} numberOfLines={1}>
              {loan.student.full_name}
            </Text>
            <Text style={[styles.studentMeta, { color: theme.textSecondary }]} numberOfLines={1}>
              Carnet {loan.student.carnet} · {loan.student.carrera}
            </Text>
          </View>
        </View>
      ) : null}

      <View style={[styles.dates, { borderColor: theme.border }]}>
        <View style={styles.dateItem}>
          <Text style={[styles.dateLabel, { color: theme.textSecondary }]}>Solicitado</Text>
          <Text style={[styles.dateValue, { color: theme.text }]}>{formatDate(loan.loan_date)}</Text>
        </View>
        <View style={styles.dateItem}>
          <Text style={[styles.dateLabel, { color: theme.textSecondary }]}>Devolver antes</Text>
          <Text style={[styles.dateValue, { color: overdue ? theme.danger : theme.text }]}>
            {formatDate(loan.due_date)}
          </Text>
        </View>
        {loan.return_date ? (
          <View style={styles.dateItem}>
            <Text style={[styles.dateLabel, { color: theme.textSecondary }]}>Devuelto</Text>
            <Text style={[styles.dateValue, { color: theme.success }]}>
              {formatDate(loan.return_date)}
            </Text>
          </View>
        ) : null}
      </View>

      {loan.notes ? (
        <View style={[styles.notes, { backgroundColor: theme.backgroundSelected }]}>
          <Ionicons name="document-text-outline" size={14} color={theme.textSecondary} />
          <Text style={[styles.notesText, { color: theme.textSecondary }]}>{loan.notes}</Text>
        </View>
      ) : null}

      {hint ? (
        <View style={styles.hint}>
          <Ionicons name={hint.icon} size={15} color={hint.color} />
          <Text style={[styles.hintText, { color: hint.color }]}>{hint.text}</Text>
        </View>
      ) : null}

      {onApprove || onReject || onReturn ? (
        <View style={styles.actions}>
          {loan.status === 'pendiente' && onApprove && onReject ? (
            <>
              <Button
                title="Aprobar"
                onPress={onApprove}
                variant="success"
                size="sm"
                icon="checkmark"
                loading={busyAction === 'aprobado'}
                disabled={busyAction !== null}
                style={styles.actionButton}
              />
              <Button
                title="Rechazar"
                onPress={onReject}
                variant="danger"
                size="sm"
                icon="close"
                loading={busyAction === 'rechazado'}
                disabled={busyAction !== null}
                style={styles.actionButton}
              />
            </>
          ) : null}

          {loan.status === 'aprobado' && onReturn ? (
            <Button
              title="Marcar como devuelto"
              onPress={onReturn}
              variant="primary"
              size="sm"
              icon="arrow-undo-outline"
              loading={busyAction === 'devuelto'}
              disabled={busyAction !== null}
            />
          ) : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: Radii.lg,
    padding: Spacing.three,
    gap: Spacing.two,
  },
  header: {
    flexDirection: 'row',
    gap: Spacing.two + 2,
  },
  image: {
    width: 62,
    height: 62,
    borderRadius: Radii.md,
  },
  headerContent: {
    flex: 1,
    gap: 2,
  },
  name: {
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  category: {
    fontSize: 12,
  },
  studentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.two,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: Spacing.two,
  },
  studentContent: {
    flex: 1,
  },
  studentName: {
    fontSize: 13,
    fontWeight: '700',
  },
  studentMeta: {
    fontSize: 11,
  },
  dates: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.three,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: Spacing.two,
  },
  dateItem: {
    minWidth: 96,
  },
  dateLabel: {
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  dateValue: {
    fontSize: 13,
    fontWeight: '600',
    marginTop: 1,
  },
  notes: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.two,
    borderRadius: Radii.sm,
    padding: Spacing.two,
  },
  notesText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 17,
  },
  hint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.two,
  },
  hintText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '600',
  },
  actions: {
    flexDirection: 'row',
    gap: Spacing.two,
    marginTop: Spacing.one,
  },
  actionButton: {
    flex: 1,
  },
});
