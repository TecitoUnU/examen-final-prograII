import type { Session } from '@supabase/supabase-js';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren,
} from 'react';

import { getErrorMessage } from '@/lib/errors';
import { updateOwnProfile } from '@/lib/api';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';
import { uploadAvatar } from '@/lib/storage';
import type { Profile, SignUpInput } from '@/types';

type SignUpPayload = SignUpInput & { avatarUri?: string | null };

type SignUpResult = {
  /** true cuando Supabase exige confirmar el correo antes de iniciar sesión. */
  needsEmailConfirmation: boolean;
};

type AuthContextValue = {
  session: Session | null;
  profile: Profile | null;
  initializing: boolean;
  profileLoading: boolean;
  profileError: string | null;
  isAdmin: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (input: SignUpPayload) => Promise<SignUpResult>;
  signOut: () => Promise<void>;
  updateProfile: (input: {
    fullName: string;
    carrera: string;
    avatarUri?: string | null;
    removeAvatar?: boolean;
  }) => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: PropsWithChildren) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);
  const mountedRef = useRef(true);

  const fetchProfile = useCallback(async (userId: string) => {
    if (!mountedRef.current) return;

    setProfileLoading(true);
    setProfileError(null);

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (!mountedRef.current) return;

    if (error) {
      setProfileError(getErrorMessage(error));
      setProfile(null);
    } else if (!data) {
      setProfileError(
        'No se encontró tu perfil. Verifica que el esquema de Supabase esté configurado correctamente.'
      );
      setProfile(null);
    } else {
      setProfile(data as Profile);
    }

    setProfileLoading(false);
  }, []);

  useEffect(() => {
    mountedRef.current = true;

    if (!isSupabaseConfigured) {
      setInitializing(false);
      return () => {
        mountedRef.current = false;
      };
    }

    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (mountedRef.current) {
          setSession(data.session);
        }
      })
      .catch(() => {
        // Sin conexión: la app sigue funcionando y muestra el login.
      })
      .finally(() => {
        if (mountedRef.current) {
          setInitializing(false);
        }
      });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!mountedRef.current) return;

      setSession(nextSession);

      if (!nextSession) {
        setProfile(null);
        setProfileError(null);
        setProfileLoading(false);
      }
    });

    return () => {
      mountedRef.current = false;
      subscription.unsubscribe();
    };
  }, []);

  const userId = session?.user?.id;

  useEffect(() => {
    if (!userId) {
      setProfile(null);
      return;
    }

    fetchProfile(userId);
  }, [userId, fetchProfile]);

  const refreshProfile = useCallback(async () => {
    if (userId) {
      await fetchProfile(userId);
    }
  }, [fetchProfile, userId]);

  const signIn = useCallback(async (email: string, password: string) => {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase no está configurado. Agrega las variables de entorno.');
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });

    if (error) throw error;
  }, []);

  const signUp = useCallback(async (input: SignUpPayload): Promise<SignUpResult> => {
    if (!isSupabaseConfigured) {
      throw new Error('Supabase no está configurado. Agrega las variables de entorno.');
    }

    const carnet = input.carnet.trim().toUpperCase();

    const { data: available, error: carnetError } = await supabase.rpc('carnet_disponible', {
      p_carnet: carnet,
    });

    if (carnetError) throw carnetError;

    if (available === false) {
      throw new Error('El carnet ya está registrado en otra cuenta.');
    }

    const { data, error } = await supabase.auth.signUp({
      email: input.email.trim().toLowerCase(),
      password: input.password,
      options: {
        data: {
          full_name: input.fullName.trim(),
          carnet,
          carrera: input.carrera.trim(),
        },
      },
    });

    if (error) throw error;

    // Con confirmación de correo activa no hay sesión todavía; la foto se
    // podrá agregar luego desde el perfil.
    if (data.session && data.user && input.avatarUri) {
      try {
        const avatarUrl = await uploadAvatar(data.user.id, input.avatarUri);
        const updated = await updateOwnProfile({
          userId: data.user.id,
          fullName: input.fullName.trim(),
          carrera: input.carrera.trim(),
          avatarUrl,
        });

        if (mountedRef.current) {
          setProfile(updated);
        }
      } catch {
        // La cuenta ya se creó; no bloqueamos el registro por una foto.
      }
    }

    return { needsEmailConfirmation: !data.session };
  }, []);

  const signOut = useCallback(async () => {
    // `scope: 'local'` borra la sesión del dispositivo antes de avisar al
    // servidor. Así el cierre de sesión funciona incluso sin conexión, y si
    // la revocación remota falla el usuario igual queda desconectado aquí.
    const { error } = await supabase.auth.signOut({ scope: 'local' });

    if (error) {
      console.warn('No se pudo revocar la sesión en el servidor:', error.message);
    }

    if (mountedRef.current) {
      setSession(null);
      setProfile(null);
      setProfileError(null);
      setProfileLoading(false);
    }
  }, []);

  const updateProfile = useCallback(
    async (input: {
      fullName: string;
      carrera: string;
      avatarUri?: string | null;
      removeAvatar?: boolean;
    }) => {
      if (!session?.user) {
        throw new Error('No hay una sesión activa.');
      }

      let avatarUrl = profile?.avatar_url ?? null;

      if (input.removeAvatar) {
        avatarUrl = null;
      } else if (input.avatarUri) {
        avatarUrl = await uploadAvatar(session.user.id, input.avatarUri);
      }

      const updated = await updateOwnProfile({
        userId: session.user.id,
        fullName: input.fullName.trim(),
        carrera: input.carrera.trim(),
        avatarUrl,
      });

      setProfile(updated);
      setProfileError(null);
    },
    [profile, session]
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      profile,
      initializing,
      profileLoading,
      profileError,
      isAdmin: profile?.role === 'administrador',
      signIn,
      signUp,
      signOut,
      updateProfile,
      refreshProfile,
    }),
    [
      session,
      profile,
      initializing,
      profileLoading,
      profileError,
      signIn,
      signUp,
      signOut,
      updateProfile,
      refreshProfile,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth debe usarse dentro de <AuthProvider>.');
  }

  return context;
}
