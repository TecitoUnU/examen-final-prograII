# LabPréstamos

Aplicación móvil (Expo + React Native) para el préstamo de equipos de laboratorio, con backend en Supabase y dos roles:

- **Estudiante:** se registra, consulta el catálogo y solicita préstamos.
- **Administrador:** aprueba o rechaza solicitudes, registra devoluciones y consulta el reporte de equipos más solicitados.

## Requisitos

- Node.js 20 o superior
- Una cuenta y un proyecto de [Supabase](https://supabase.com)
- Expo Go en el teléfono, o un emulador de Android/iOS

## Puesta en marcha

1. Instala las dependencias:

   ```bash
   npm install
   ```

2. Configura las variables de entorno en un archivo `.env`:

   ```env
   EXPO_PUBLIC_SUPABASE_URL=https://tu-proyecto.supabase.co
   EXPO_PUBLIC_SUPABASE_ANON_KEY=tu_publishable_key_o_anon_key
   ```

3. En el **SQL Editor** de Supabase ejecuta, en orden:

   - `supabase/schema.sql`
   - `supabase/seed.sql` (opcional, agrega equipos de ejemplo)

4. Verifica la conexión:

   ```bash
   npm run check:supabase
   ```

5. Inicia la app:

   ```bash
   npx expo start
   ```

En Windows/PowerShell puede que necesites usar `npx.cmd`.

## Convertir una cuenta en administrador

Registra la cuenta desde la app y luego ejecuta en Supabase:

```sql
update public.profiles
   set role = 'administrador'
 where id = (select id from auth.users where email = 'admin@universidad.edu');
```

Cierra sesión y vuelve a iniciarla para ver las pestañas **Solicitudes** y **Reporte**.

## Comandos útiles

```bash
npx expo start        # servidor de desarrollo
npx tsc --noEmit      # verificación de tipos
npx expo lint         # lint
npx expo-doctor       # diagnóstico de dependencias y configuración
```

## Estructura

```text
src/
├── app/              # Rutas de Expo Router
│   ├── (auth)/       # Login y registro
│   └── (app)/        # Catálogo, préstamos, perfil y panel admin
├── components/       # Componentes reutilizables
├── constants/        # Tema y etiquetas de estado
├── context/          # Sesión y perfil (Supabase Auth)
├── hooks/            # Consultas y tema
├── lib/              # Cliente de Supabase, API, formato y errores
└── types/            # Tipos compartidos
supabase/             # Esquema SQL y datos de ejemplo
```

La guía completa de configuración, RLS y pruebas está en [`GUIA_SUPABASE.md`](./GUIA_SUPABASE.md).
