// https://docs.expo.dev/guides/using-eslint/
const { defineConfig } = require('eslint/config');
const expoConfig = require('eslint-config-expo/flat');

module.exports = defineConfig([
  expoConfig,
  {
    ignores: ['dist/*'],
  },
  {
    files: ['**/*.{ts,tsx}'],
    rules: {
      // Los hooks de consulta cargan datos desde un efecto y actualizan su
      // estado; es el patrón habitual de fetching y no un render en cascada.
      'react-hooks/set-state-in-effect': 'off',
    },
  },
]);
